package com.fiatx2.vortexcore;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.Material;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Scoreboard;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * ระบบทีม
 * /team create|invite|accept|deny|leave|kick|disband|transfer|list|info
 * /tc [ข้อความ]  แชททีม (ไม่ใส่ข้อความ = สลับโหมดแชททีม)
 * เพื่อนร่วมทีมตีกันไม่ได้ (ปรับได้ใน config: team.friendly-fire)
 */
public class TeamModule implements CommandExecutor, TabCompleter, Listener {

    private static final Pattern NAME = Pattern.compile("[\\p{L}\\p{N}_]+");
    private static final long INVITE_MS = 60_000;

    private static class Team {
        String name;
        UUID leader;
        final Set<UUID> members = new LinkedHashSet<>();
        // ---- ตั้งค่าทีม (/teamsettings) ----
        boolean friendlyFire;      // ตีกันเองได้
        boolean showTag = true;    // แสดง [ชื่อทีม] บนหัว
        NamedTextColor color = NamedTextColor.AQUA;
        boolean tpaAuto;           // /tpa หากันในทีมโดยไม่ต้องกดตกลง
        boolean memberInvite;      // สมาชิกทั่วไปเชิญคนเข้าทีมได้
    }

    private static class SettingsHolder implements InventoryHolder {
        Inventory inv;

        @Override
        public Inventory getInventory() { return inv; }
    }

    private static final List<NamedTextColor> COLORS = List.of(
            NamedTextColor.AQUA, NamedTextColor.GREEN, NamedTextColor.YELLOW, NamedTextColor.GOLD,
            NamedTextColor.RED, NamedTextColor.LIGHT_PURPLE, NamedTextColor.BLUE,
            NamedTextColor.WHITE, NamedTextColor.GRAY);
    private static final Map<NamedTextColor, String> COLOR_DYE = Map.of(
            NamedTextColor.AQUA, "LIGHT_BLUE", NamedTextColor.GREEN, "LIME", NamedTextColor.YELLOW, "YELLOW",
            NamedTextColor.GOLD, "ORANGE", NamedTextColor.RED, "RED", NamedTextColor.LIGHT_PURPLE, "PINK",
            NamedTextColor.BLUE, "BLUE", NamedTextColor.WHITE, "WHITE", NamedTextColor.GRAY, "GRAY");
    private static final Map<NamedTextColor, String> COLOR_TH = Map.of(
            NamedTextColor.AQUA, "ฟ้า", NamedTextColor.GREEN, "เขียว", NamedTextColor.YELLOW, "เหลือง",
            NamedTextColor.GOLD, "ส้ม", NamedTextColor.RED, "แดง", NamedTextColor.LIGHT_PURPLE, "ชมพู",
            NamedTextColor.BLUE, "น้ำเงิน", NamedTextColor.WHITE, "ขาว", NamedTextColor.GRAY, "เทา");

    private static final String TAG_PREFIX = "vt_";
    private static final int SLOT_FF = 11, SLOT_TAG = 12, SLOT_COLOR = 13, SLOT_TPA = 14, SLOT_INVITE = 15;
    private BukkitTask tagTask;

    private static class Invite {
        final String team;
        final UUID from;
        final long until;

        Invite(String team, UUID from, long until) {
            this.team = team;
            this.from = from;
            this.until = until;
        }
    }

    private final VortexCore plugin;
    private final File file;
    private final Map<String, Team> teams = new HashMap<>();          // key = ชื่อตัวพิมพ์เล็ก
    private final Map<UUID, String> memberTeam = new HashMap<>();      // ผู้เล่น -> key ทีม
    private final Map<UUID, Invite> invites = new HashMap<>();         // ผู้ถูกเชิญ -> คำเชิญ
    private final Set<UUID> chatMode = new HashSet<>();

    public TeamModule(VortexCore plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "teams.yml");
    }

    // ---------------- config ----------------

    private int maxMembers() { return Math.max(2, plugin.getConfig().getInt("team.max-members", 5)); }

    private int maxName() { return Math.max(3, plugin.getConfig().getInt("team.max-name-length", 12)); }

    private boolean defaultFriendlyFire() { return plugin.getConfig().getBoolean("team.friendly-fire", false); }

    // ---------------- data ----------------

    public void load() {
        teams.clear();
        memberTeam.clear();
        plugin.getDataFolder().mkdirs();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        var sec = y.getConfigurationSection("teams");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            try {
                Team t = new Team();
                t.name = sec.getString(key + ".name", key);
                t.leader = UUID.fromString(sec.getString(key + ".leader", ""));
                for (String m : sec.getStringList(key + ".members")) t.members.add(UUID.fromString(m));
                t.friendlyFire = sec.getBoolean(key + ".settings.friendly-fire", defaultFriendlyFire());
                t.showTag = sec.getBoolean(key + ".settings.show-tag", true);
                NamedTextColor c = NamedTextColor.NAMES.value(sec.getString(key + ".settings.color", "aqua"));
                t.color = c != null && COLORS.contains(c) ? c : NamedTextColor.AQUA;
                t.tpaAuto = sec.getBoolean(key + ".settings.tpa-auto", false);
                t.memberInvite = sec.getBoolean(key + ".settings.member-invite", false);
                if (t.members.isEmpty()) continue;
                if (!t.members.contains(t.leader)) t.leader = t.members.iterator().next();
                teams.put(key, t);
                for (UUID m : t.members) memberTeam.put(m, key);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("teams.yml: ข้ามทีม '" + key + "' (ข้อมูลเสีย)");
            }
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<String, Team> en : teams.entrySet()) {
            Team t = en.getValue();
            String b = "teams." + en.getKey();
            y.set(b + ".name", t.name);
            y.set(b + ".leader", t.leader.toString());
            y.set(b + ".members", t.members.stream().map(UUID::toString).toList());
            y.set(b + ".settings.friendly-fire", t.friendlyFire);
            y.set(b + ".settings.show-tag", t.showTag);
            y.set(b + ".settings.color", NamedTextColor.NAMES.key(t.color));
            y.set(b + ".settings.tpa-auto", t.tpaAuto);
            y.set(b + ".settings.member-invite", t.memberInvite);
        }
        try {
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("teams.yml save failed: " + ex.getMessage());
        }
        if (plugin.isEnabled()) syncTags();
    }

    // ---------------- tag บนหัว ([ชื่อทีม] นำหน้าชื่อ) ----------------

    public void start() {
        tagTask = Bukkit.getScheduler().runTaskTimer(plugin, this::syncTags, 40L, 40L);
    }

    public void shutdown() {
        if (tagTask != null) tagTask.cancel();
        for (Player v : Bukkit.getOnlinePlayers()) {
            for (org.bukkit.scoreboard.Team st : new ArrayList<>(v.getScoreboard().getTeams())) {
                if (st.getName().startsWith(TAG_PREFIX)) st.unregister();
            }
        }
    }

    private String tagId(Team t) { return TAG_PREFIX + Integer.toHexString(key(t).hashCode()); }

    public void syncTags() {
        for (Player viewer : Bukkit.getOnlinePlayers()) syncFor(viewer);
    }

    /** ทำให้ scoreboard ที่ผู้ชมกำลังใช้อยู่ (ทั้งของ sidebar ส่วนตัวและ main) มีทีมสำหรับ prefix บนหัว */
    private void syncFor(Player viewer) {
        Scoreboard sb = viewer.getScoreboard();
        Set<String> wanted = new HashSet<>();
        if (Smp.is(viewer.getWorld())) {
            for (Team t : teams.values()) {
                if (!t.showTag) continue;
                Set<String> names = new HashSet<>();
                for (UUID m : t.members) {
                    Player mp = Bukkit.getPlayer(m);
                    if (mp != null && Smp.is(mp.getWorld())) names.add(mp.getName());
                }
                if (names.isEmpty()) continue;
                String id = tagId(t);
                wanted.add(id);
                org.bukkit.scoreboard.Team st = sb.getTeam(id);
                if (st == null) st = sb.registerNewTeam(id);
                st.prefix(Component.text("[" + t.name + "] ", t.color));
                for (String en : new ArrayList<>(st.getEntries())) if (!names.contains(en)) st.removeEntry(en);
                for (String n : names) if (!st.hasEntry(n)) st.addEntry(n);
            }
        }
        for (org.bukkit.scoreboard.Team st : new ArrayList<>(sb.getTeams())) {
            if (st.getName().startsWith(TAG_PREFIX) && !wanted.contains(st.getName())) st.unregister();
        }
    }

    /** ใช้กับ /tpa: คนในทีมเดียวกันและทีมเปิด tpa-auto = ตกลงให้อัตโนมัติ */
    public boolean autoAccept(Player a, Player b) {
        Team t = teamOf(a.getUniqueId());
        return t != null && t.tpaAuto && sameTeam(a.getUniqueId(), b.getUniqueId());
    }

    // ---------------- helpers ----------------

    private Component msg(String s, NamedTextColor c) { return Component.text(s, c); }

    private void err(Player p, String s) { p.sendMessage(msg(s, NamedTextColor.RED)); }

    private void ok(Player p, String s) { p.sendMessage(msg(s, NamedTextColor.GREEN)); }

    private Team teamOf(UUID id) {
        String k = memberTeam.get(id);
        return k == null ? null : teams.get(k);
    }

    private String key(Team t) { return t.name.toLowerCase(); }

    private String nameOf(UUID id) {
        OfflinePlayer op = Bukkit.getOfflinePlayer(id);
        return op.getName() != null ? op.getName() : id.toString().substring(0, 8);
    }

    private void broadcast(Team t, Component c) {
        for (UUID m : t.members) {
            Player p = Bukkit.getPlayer(m);
            if (p != null) p.sendMessage(c);
        }
    }

    /** ชื่อทีมของผู้เล่น (null = ไม่มีทีม) — เผื่อใช้กับ scoreboard/ปลั๊กอินอื่น */
    public String getTeamName(Player p) {
        Team t = teamOf(p.getUniqueId());
        return t == null ? null : t.name;
    }

    public NamedTextColor getTeamColor(Player p) {
        Team t = teamOf(p.getUniqueId());
        return t == null ? NamedTextColor.WHITE : t.color;
    }

    public boolean sameTeam(UUID a, UUID b) {
        String ka = memberTeam.get(a);
        return ka != null && ka.equals(memberTeam.get(b));
    }

    // ---------------- command ----------------

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args) {
        if (!(s instanceof Player p)) {
            s.sendMessage("เฉพาะผู้เล่นเท่านั้น");
            return true;
        }
        if (!Smp.is(p.getWorld())) {
            Smp.notHere(p);
            return true;
        }
        if (cmd.getName().equalsIgnoreCase("tc")) {
            teamChat(p, args);
            return true;
        }
        if (cmd.getName().equalsIgnoreCase("teamsettings")) {
            openSettings(p);
            return true;
        }
        if (args.length == 0) {
            if (teamOf(p.getUniqueId()) != null) info(p, null);
            else help(p);
            return true;
        }
        String sub = args[0].toLowerCase();
        String[] rest = java.util.Arrays.copyOfRange(args, 1, args.length);
        switch (sub) {
            case "create" -> create(p, rest);
            case "invite" -> invite(p, rest);
            case "accept" -> accept(p);
            case "deny" -> deny(p);
            case "leave" -> leave(p);
            case "kick" -> kick(p, rest);
            case "disband" -> disband(p);
            case "transfer" -> transfer(p, rest);
            case "list" -> list(p);
            case "info" -> info(p, rest.length > 0 ? rest[0] : null);
            default -> help(p);
        }
        return true;
    }

    private void help(Player p) {
        p.sendMessage(msg("--- Team ---", NamedTextColor.GOLD));
        for (String l : List.of(
                "/team create <ชื่อ> - สร้างทีม",
                "/team invite <ผู้เล่น> - เชิญเข้าทีม",
                "/team accept | deny - รับ/ปฏิเสธคำเชิญ",
                "/team leave - ออกจากทีม",
                "/team kick <ผู้เล่น> - เตะออก (หัวหน้า)",
                "/team transfer <ผู้เล่น> - โอนหัวหน้า",
                "/team disband - ยุบทีม (หัวหน้า)",
                "/team info [ชื่อ] | list - ดูข้อมูลทีม",
                "/teamsettings - ตั้งค่าทีม (ตีกันได้/แท็กบนหัว/สี ฯลฯ)",
                "/tc [ข้อความ] - แชททีม")) {
            p.sendMessage(msg(l, NamedTextColor.YELLOW));
        }
    }

    private void create(Player p, String[] args) {
        if (teamOf(p.getUniqueId()) != null) {
            err(p, "คุณมีทีมอยู่แล้ว ใช้ /team leave ก่อน");
            return;
        }
        if (args.length != 1) {
            err(p, "ใช้: /team create <ชื่อ>");
            return;
        }
        String name = args[0];
        if (name.length() < 3 || name.length() > maxName() || !NAME.matcher(name).matches()) {
            err(p, "ชื่อทีมต้องยาว 3-" + maxName() + " ตัวอักษร (ตัวอักษร/ตัวเลข/_ เท่านั้น)");
            return;
        }
        if (teams.containsKey(name.toLowerCase())) {
            err(p, "ชื่อทีมนี้ถูกใช้แล้ว");
            return;
        }
        Team t = new Team();
        t.name = name;
        t.leader = p.getUniqueId();
        t.members.add(p.getUniqueId());
        t.friendlyFire = defaultFriendlyFire();
        teams.put(key(t), t);
        memberTeam.put(p.getUniqueId(), key(t));
        save();
        ok(p, "สร้างทีม \"" + name + "\" แล้ว ใช้ /team invite <ผู้เล่น> เพื่อเชิญเพื่อน และ /teamsettings เพื่อตั้งค่าทีม");
    }

    private void invite(Player p, String[] args) {
        Team t = teamOf(p.getUniqueId());
        if (t == null) {
            err(p, "คุณยังไม่มีทีม ใช้ /team create <ชื่อ>");
            return;
        }
        if (!t.leader.equals(p.getUniqueId()) && !t.memberInvite) {
            err(p, "เฉพาะหัวหน้าทีมเท่านั้นที่เชิญได้");
            return;
        }
        if (args.length != 1) {
            err(p, "ใช้: /team invite <ผู้เล่น>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null || !target.isOnline()) {
            err(p, "ไม่พบผู้เล่นคนนี้");
            return;
        }
        if (target.equals(p)) {
            err(p, "เชิญตัวเองไม่ได้");
            return;
        }
        if (teamOf(target.getUniqueId()) != null) {
            err(p, target.getName() + " มีทีมอยู่แล้ว");
            return;
        }
        if (t.members.size() >= maxMembers()) {
            err(p, "ทีมเต็มแล้ว (สูงสุด " + maxMembers() + " คน)");
            return;
        }
        invites.put(target.getUniqueId(), new Invite(key(t), p.getUniqueId(), System.currentTimeMillis() + INVITE_MS));
        ok(p, "ส่งคำเชิญไปหา " + target.getName() + " แล้ว (หมดอายุใน 60 วินาที)");
        target.sendMessage(msg(p.getName() + " เชิญคุณเข้าทีม \"" + t.name + "\"", NamedTextColor.GOLD));
        target.sendMessage(msg("พิมพ์ /team accept เพื่อเข้าร่วม หรือ /team deny เพื่อปฏิเสธ", NamedTextColor.YELLOW));
    }

    private Invite takeInvite(Player p) {
        Invite inv = invites.remove(p.getUniqueId());
        if (inv == null || System.currentTimeMillis() > inv.until) return null;
        return inv;
    }

    private void accept(Player p) {
        Invite inv = takeInvite(p);
        if (inv == null) {
            err(p, "ไม่มีคำเชิญ หรือคำเชิญหมดอายุแล้ว");
            return;
        }
        if (teamOf(p.getUniqueId()) != null) {
            err(p, "คุณมีทีมอยู่แล้ว");
            return;
        }
        Team t = teams.get(inv.team);
        if (t == null) {
            err(p, "ทีมนี้ไม่มีอยู่แล้ว");
            return;
        }
        if (t.members.size() >= maxMembers()) {
            err(p, "ทีมเต็มแล้ว");
            return;
        }
        t.members.add(p.getUniqueId());
        memberTeam.put(p.getUniqueId(), inv.team);
        save();
        broadcast(t, msg(p.getName() + " เข้าร่วมทีมแล้ว", NamedTextColor.GREEN));
    }

    private void deny(Player p) {
        Invite inv = takeInvite(p);
        if (inv == null) {
            err(p, "ไม่มีคำเชิญ");
            return;
        }
        p.sendMessage(msg("ปฏิเสธคำเชิญแล้ว", NamedTextColor.GRAY));
        Player from = Bukkit.getPlayer(inv.from);
        if (from != null) from.sendMessage(msg(p.getName() + " ปฏิเสธคำเชิญเข้าทีม", NamedTextColor.GRAY));
    }

    private void removeMember(Team t, UUID id) {
        t.members.remove(id);
        memberTeam.remove(id);
        chatMode.remove(id);
    }

    private void leave(Player p) {
        Team t = teamOf(p.getUniqueId());
        if (t == null) {
            err(p, "คุณยังไม่มีทีม");
            return;
        }
        UUID id = p.getUniqueId();
        removeMember(t, id);
        if (t.members.isEmpty()) {
            teams.remove(key(t));
        } else if (t.leader.equals(id)) {
            t.leader = t.members.iterator().next();
            broadcast(t, msg(nameOf(t.leader) + " เป็นหัวหน้าทีมคนใหม่", NamedTextColor.GOLD));
        }
        save();
        p.sendMessage(msg("ออกจากทีม \"" + t.name + "\" แล้ว", NamedTextColor.YELLOW));
        broadcast(t, msg(p.getName() + " ออกจากทีม", NamedTextColor.YELLOW));
    }

    private void kick(Player p, String[] args) {
        Team t = teamOf(p.getUniqueId());
        if (t == null || !t.leader.equals(p.getUniqueId())) {
            err(p, "เฉพาะหัวหน้าทีมเท่านั้น");
            return;
        }
        if (args.length != 1) {
            err(p, "ใช้: /team kick <ผู้เล่น>");
            return;
        }
        UUID target = findMember(t, args[0]);
        if (target == null) {
            err(p, "ไม่พบสมาชิกชื่อนี้ในทีม");
            return;
        }
        if (target.equals(p.getUniqueId())) {
            err(p, "เตะตัวเองไม่ได้ ใช้ /team leave หรือ /team disband");
            return;
        }
        removeMember(t, target);
        save();
        ok(p, "เตะ " + nameOf(target) + " ออกจากทีมแล้ว");
        Player tp = Bukkit.getPlayer(target);
        if (tp != null) tp.sendMessage(msg("คุณถูกเตะออกจากทีม \"" + t.name + "\"", NamedTextColor.RED));
        broadcast(t, msg(nameOf(target) + " ถูกเตะออกจากทีม", NamedTextColor.YELLOW));
    }

    private void transfer(Player p, String[] args) {
        Team t = teamOf(p.getUniqueId());
        if (t == null || !t.leader.equals(p.getUniqueId())) {
            err(p, "เฉพาะหัวหน้าทีมเท่านั้น");
            return;
        }
        if (args.length != 1) {
            err(p, "ใช้: /team transfer <ผู้เล่น>");
            return;
        }
        UUID target = findMember(t, args[0]);
        if (target == null || target.equals(p.getUniqueId())) {
            err(p, "ไม่พบสมาชิกคนนั้น (ต้องเป็นสมาชิกอื่นในทีม)");
            return;
        }
        t.leader = target;
        save();
        broadcast(t, msg(nameOf(target) + " เป็นหัวหน้าทีมคนใหม่", NamedTextColor.GOLD));
    }

    private void disband(Player p) {
        Team t = teamOf(p.getUniqueId());
        if (t == null || !t.leader.equals(p.getUniqueId())) {
            err(p, "เฉพาะหัวหน้าทีมเท่านั้น");
            return;
        }
        broadcast(t, msg("ทีม \"" + t.name + "\" ถูกยุบแล้ว", NamedTextColor.RED));
        for (UUID m : new ArrayList<>(t.members)) removeMember(t, m);
        teams.remove(key(t));
        save();
    }

    private UUID findMember(Team t, String name) {
        for (UUID m : t.members) if (nameOf(m).equalsIgnoreCase(name)) return m;
        return null;
    }

    private void list(Player p) {
        if (teams.isEmpty()) {
            p.sendMessage(msg("ยังไม่มีทีมในเซิร์ฟ", NamedTextColor.GRAY));
            return;
        }
        p.sendMessage(msg("--- ทีมทั้งหมด (" + teams.size() + ") ---", NamedTextColor.GOLD));
        for (Team t : teams.values()) {
            long online = t.members.stream().filter(m -> Bukkit.getPlayer(m) != null).count();
            p.sendMessage(msg(t.name + " | " + t.members.size() + "/" + maxMembers() + " คน | ออนไลน์ " + online,
                    NamedTextColor.YELLOW));
        }
    }

    private void info(Player p, String name) {
        Team t = name == null ? teamOf(p.getUniqueId()) : teams.get(name.toLowerCase());
        if (t == null) {
            err(p, name == null ? "คุณยังไม่มีทีม" : "ไม่พบทีมชื่อนี้");
            return;
        }
        p.sendMessage(msg("--- ทีม " + t.name + " (" + t.members.size() + "/" + maxMembers() + ") ---", NamedTextColor.GOLD));
        for (UUID m : t.members) {
            boolean on = Bukkit.getPlayer(m) != null;
            String tag = m.equals(t.leader) ? " ★หัวหน้า" : "";
            p.sendMessage(msg((on ? "● " : "○ ") + nameOf(m) + tag, on ? NamedTextColor.GREEN : NamedTextColor.GRAY));
        }
    }

    // ---------------- team chat ----------------

    private void sendChat(Player p, Team t, String text) {
        broadcast(t, Component.text("[Team] ", NamedTextColor.AQUA)
                .append(Component.text(p.getName() + ": ", NamedTextColor.GRAY))
                .append(Component.text(text, NamedTextColor.WHITE)));
    }

    private void teamChat(Player p, String[] args) {
        Team t = teamOf(p.getUniqueId());
        if (t == null) {
            err(p, "คุณยังไม่มีทีม");
            return;
        }
        if (args.length == 0) {
            if (chatMode.remove(p.getUniqueId())) {
                p.sendMessage(msg("ปิดโหมดแชททีมแล้ว (กลับไปแชทปกติ)", NamedTextColor.GRAY));
            } else {
                chatMode.add(p.getUniqueId());
                ok(p, "เปิดโหมดแชททีมแล้ว ทุกข้อความจะส่งหาทีมเท่านั้น (พิมพ์ /tc อีกครั้งเพื่อปิด)");
            }
            return;
        }
        sendChat(p, t, String.join(" ", args));
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        if (!chatMode.contains(p.getUniqueId())) return;
        e.setCancelled(true);
        String text = PlainTextComponentSerializer.plainText().serialize(e.message());
        Bukkit.getScheduler().runTask(plugin, () -> {
            Team t = teamOf(p.getUniqueId());
            if (t == null) {
                chatMode.remove(p.getUniqueId());
                return;
            }
            sendChat(p, t, text);
        });
    }

    // ---------------- friendly fire ----------------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Entity d = e.getDamager();
        if (d instanceof Projectile pr && pr.getShooter() instanceof Entity s) d = s;
        if (!(d instanceof Player attacker) || attacker.equals(victim)) return;
        if (!Smp.is(victim.getWorld())) return;
        Team at = teamOf(attacker.getUniqueId());
        if (at != null && !at.friendlyFire && sameTeam(attacker.getUniqueId(), victim.getUniqueId())) {
            e.setCancelled(true);
            attacker.sendActionBar(msg("ตีเพื่อนร่วมทีมไม่ได้", NamedTextColor.RED));
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        chatMode.remove(e.getPlayer().getUniqueId());
        invites.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Team t = teamOf(e.getPlayer().getUniqueId());
        if (t != null) {
            e.getPlayer().sendMessage(msg("คุณอยู่ในทีม \"" + t.name + "\"", NamedTextColor.GRAY));
        }
        // รอให้ ScoreboardModule สลับ scoreboard ให้เสร็จก่อนแล้วค่อยใส่แท็ก
        Bukkit.getScheduler().runTaskLater(plugin, this::syncTags, 10L);
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        Bukkit.getScheduler().runTaskLater(plugin, this::syncTags, 10L);
    }

    // ---------------- /teamsettings ----------------

    private ItemStack item(Material m, Component name, List<Component> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(name.decoration(TextDecoration.ITALIC, false));
        if (lore != null) {
            meta.lore(lore.stream().map(c -> c.decoration(TextDecoration.ITALIC, false)).toList());
        }
        it.setItemMeta(meta);
        return it;
    }

    private Component line(String s, NamedTextColor c) { return Component.text(s, c); }

    private void openSettings(Player p) {
        Team t = teamOf(p.getUniqueId());
        if (t == null) {
            err(p, "คุณยังไม่มีทีม ใช้ /team create <ชื่อ>");
            return;
        }
        SettingsHolder h = new SettingsHolder();
        h.inv = Bukkit.createInventory(h, 27, Component.text("Team Settings | " + t.name, NamedTextColor.DARK_GRAY));
        renderSettings(h.inv, t, t.leader.equals(p.getUniqueId()));
        p.openInventory(h.inv);
    }

    private void toggleItem(Inventory inv, int slot, Material icon, String title, boolean on, String desc, boolean leader) {
        inv.setItem(slot, item(icon, Component.text(title, on ? NamedTextColor.GREEN : NamedTextColor.RED, TextDecoration.BOLD),
                List.of(line(desc, NamedTextColor.GRAY), Component.empty(),
                        line("สถานะ: " + (on ? "เปิด" : "ปิด"), on ? NamedTextColor.GREEN : NamedTextColor.RED),
                        line(leader ? "คลิกเพื่อสลับ" : "เฉพาะหัวหน้าทีมเปลี่ยนได้", NamedTextColor.YELLOW))));
        inv.setItem(slot + 9, item(on ? Material.LIME_STAINED_GLASS_PANE : Material.RED_STAINED_GLASS_PANE,
                Component.text(on ? "เปิด" : "ปิด", on ? NamedTextColor.GREEN : NamedTextColor.RED), null));
    }

    private void renderSettings(Inventory inv, Team t, boolean leader) {
        ItemStack bg = item(Material.GRAY_STAINED_GLASS_PANE, Component.empty(), null);
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, bg);

        toggleItem(inv, SLOT_FF, Material.DIAMOND_SWORD, "Friendly Fire", t.friendlyFire,
                "เปิด = เพื่อนในทีมตีกันเองได้ / ปิด = ตีกันไม่ได้", leader);
        toggleItem(inv, SLOT_TAG, Material.NAME_TAG, "Tag บนหัว", t.showTag,
                "แสดง [" + t.name + "] นำหน้าชื่อเหนือหัวสมาชิก", leader);
        toggleItem(inv, SLOT_TPA, Material.ENDER_PEARL, "TPA ในทีม", t.tpaAuto,
                "/tpa หากันในทีมแล้ววาปทันที ไม่ต้องกดตกลง", leader);
        toggleItem(inv, SLOT_INVITE, Material.WRITABLE_BOOK, "สมาชิกเชิญได้", t.memberInvite,
                "เปิด = ทุกคนในทีมใช้ /team invite ได้ (ไม่ใช่แค่หัวหน้า)", leader);

        String dye = COLOR_DYE.getOrDefault(t.color, "LIGHT_BLUE");
        inv.setItem(SLOT_COLOR, item(Material.valueOf(dye + "_DYE"),
                Component.text("สี Tag: " + COLOR_TH.getOrDefault(t.color, "ฟ้า"), t.color, TextDecoration.BOLD),
                List.of(line("สีของ [" + t.name + "] เหนือหัว", NamedTextColor.GRAY), Component.empty(),
                        line(leader ? "คลิกซ้าย: สีถัดไป | คลิกขวา: สีก่อนหน้า" : "เฉพาะหัวหน้าทีมเปลี่ยนได้",
                                NamedTextColor.YELLOW))));
        inv.setItem(SLOT_COLOR + 9, item(Material.valueOf(dye + "_STAINED_GLASS_PANE"),
                Component.text(COLOR_TH.getOrDefault(t.color, "ฟ้า"), t.color), null));
    }

    @EventHandler
    public void onSettingsClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof SettingsHolder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(e.getView().getTopInventory())) return;
        Team t = teamOf(p.getUniqueId());
        if (t == null) {
            p.closeInventory();
            return;
        }
        int slot = e.getRawSlot();
        if (slot != SLOT_FF && slot != SLOT_TAG && slot != SLOT_COLOR && slot != SLOT_TPA && slot != SLOT_INVITE) return;
        if (!t.leader.equals(p.getUniqueId())) {
            p.sendActionBar(msg("เฉพาะหัวหน้าทีมเท่านั้นที่ตั้งค่าได้", NamedTextColor.RED));
            return;
        }
        String what;
        switch (slot) {
            case SLOT_FF -> {
                t.friendlyFire = !t.friendlyFire;
                what = "Friendly Fire: " + (t.friendlyFire ? "เปิด" : "ปิด");
            }
            case SLOT_TAG -> {
                t.showTag = !t.showTag;
                what = "Tag บนหัว: " + (t.showTag ? "เปิด" : "ปิด");
            }
            case SLOT_TPA -> {
                t.tpaAuto = !t.tpaAuto;
                what = "TPA ในทีม: " + (t.tpaAuto ? "เปิด" : "ปิด");
            }
            case SLOT_INVITE -> {
                t.memberInvite = !t.memberInvite;
                what = "สมาชิกเชิญได้: " + (t.memberInvite ? "เปิด" : "ปิด");
            }
            default -> {
                int i = COLORS.indexOf(t.color);
                int n = COLORS.size();
                i = e.isRightClick() ? (i - 1 + n) % n : (i + 1) % n;
                t.color = COLORS.get(i);
                what = "สี Tag: " + COLOR_TH.getOrDefault(t.color, "");
            }
        }
        save();
        renderSettings(h.inv, t, true);
        p.playSound(p.getLocation(), org.bukkit.Sound.UI_BUTTON_CLICK, 0.6f, 1.2f);
        broadcast(t, Component.text("[Team] ", NamedTextColor.AQUA)
                .append(Component.text("หัวหน้าตั้งค่า " + what, NamedTextColor.GRAY)));
    }

    @EventHandler
    public void onSettingsDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof SettingsHolder) e.setCancelled(true);
    }

    // ---------------- tab complete ----------------

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] args) {
        if (!(s instanceof Player p) || !cmd.getName().equalsIgnoreCase("team")) return List.of();
        if (args.length == 1) {
            return List.of("create", "invite", "accept", "deny", "leave", "kick", "disband", "transfer", "list", "info")
                    .stream().filter(x -> x.startsWith(args[0].toLowerCase())).toList();
        }
        if (args.length == 2) {
            String a = args[1].toLowerCase();
            switch (args[0].toLowerCase()) {
                case "invite" -> {
                    return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                            .filter(x -> x.toLowerCase().startsWith(a)).toList();
                }
                case "kick", "transfer" -> {
                    Team t = teamOf(p.getUniqueId());
                    if (t == null) return List.of();
                    return t.members.stream().map(this::nameOf)
                            .filter(x -> x.toLowerCase().startsWith(a)).toList();
                }
                case "info" -> {
                    return teams.values().stream().map(t -> t.name)
                            .filter(x -> x.toLowerCase().startsWith(a)).toList();
                }
                default -> {
                    return List.of();
                }
            }
        }
        return List.of();
    }
}
