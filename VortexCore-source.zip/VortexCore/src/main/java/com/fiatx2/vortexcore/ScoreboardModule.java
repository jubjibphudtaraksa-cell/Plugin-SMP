package com.fiatx2.vortexcore;

import io.papermc.paper.scoreboard.numbers.NumberFormat;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Vortex SMP - sidebar scoreboard แยกของแต่ละคน (แสดงเฉพาะตอนผู้เล่นอยู่ในโลก smp)
 * อยู่นอกโลก smp -> คืน scoreboard หลักให้
 */
public final class ScoreboardModule implements Listener {

    private static final TextColor PURPLE = TextColor.color(0xA020F0);
    private static final String[] ENTRIES = {"§0", "§1", "§2", "§3"};

    private final VortexCore plugin;
    private final Map<UUID, Scoreboard> boards = new HashMap<>();

    public ScoreboardModule(VortexCore plugin) {
        this.plugin = plugin;
    }

    public void start() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                tick(player);
            }
        }, 20L, 20L);
    }

    public void shutdown() {
        Scoreboard main = Bukkit.getScoreboardManager().getMainScoreboard();
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (boards.containsValue(player.getScoreboard())) {
                player.setScoreboard(main);
            }
        }
        boards.clear();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        boards.remove(event.getPlayer().getUniqueId());
    }

    private void tick(Player player) {
        Scoreboard main = Bukkit.getScoreboardManager().getMainScoreboard();
        Scoreboard mine = boards.get(player.getUniqueId());

        if (!Smp.is(player.getWorld())) {
            // นอกโลก smp: เอา board ของเราออก (ถ้ายังแสดงอยู่)
            if (mine != null && player.getScoreboard() == mine) {
                player.setScoreboard(main);
            }
            return;
        }

        if (mine == null) {
            mine = createBoard();
            boards.put(player.getUniqueId(), mine);
        }
        if (player.getScoreboard() != mine) {
            player.setScoreboard(mine);
        }
        updateBoard(player, mine);
    }

    private Scoreboard createBoard() {
        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective objective = board.registerNewObjective(
                "vortex", Criteria.DUMMY,
                Component.text("Vortex SMP", PURPLE, TextDecoration.BOLD));
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        objective.numberFormat(NumberFormat.blank());
        objective.getScore(ENTRIES[0]).setScore(3);
        objective.getScore(ENTRIES[1]).setScore(2);
        objective.getScore(ENTRIES[2]).setScore(1);
        objective.getScore(ENTRIES[3]).setScore(0);
        return board;
    }

    private void updateBoard(Player player, Scoreboard board) {
        Objective objective = board.getObjective("vortex");
        if (objective == null) return;

        Component nameLine = Component.text(player.getName(), NamedTextColor.AQUA, TextDecoration.BOLD);

        long ticks = player.getStatistic(Statistic.PLAY_ONE_MINUTE);
        Component timeLine = Component.text("Playtime ", NamedTextColor.YELLOW)
                .append(Component.text(formatTime(ticks / 20L), NamedTextColor.WHITE));

        int kills = player.getStatistic(Statistic.PLAYER_KILLS);
        int deaths = player.getStatistic(Statistic.DEATHS);
        Component kdLine = Component.text("Kill/Dead ", NamedTextColor.GOLD)
                .append(Component.text(kills, NamedTextColor.GREEN))
                .append(Component.text("(", NamedTextColor.GRAY))
                .append(Component.text(deaths, NamedTextColor.RED))
                .append(Component.text(")", NamedTextColor.GRAY));

        objective.getScore(ENTRIES[0]).customName(nameLine);
        objective.getScore(ENTRIES[1]).customName(timeLine);
        objective.getScore(ENTRIES[2]).customName(kdLine);
        objective.getScore(ENTRIES[3]).customName(
                Component.text("IP: ", NamedTextColor.LIGHT_PURPLE)
                        .append(Component.text("play.svmine.com:11249", NamedTextColor.WHITE)));
    }

    private static String formatTime(long totalSeconds) {
        long days = totalSeconds / 86400;
        long hours = (totalSeconds % 86400) / 3600;
        long minutes = (totalSeconds % 3600) / 60;
        if (days > 0) return days + "d " + hours + "h " + minutes + "m";
        return hours + "h " + minutes + "m";
    }
}
