package com.fiatx2.vortexcore;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import net.milkbowl.vault.economy.EconomyResponse.ResponseType;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.ServicePriority;

import java.util.List;
import java.util.UUID;

/**
 * ลงทะเบียนเป็น Vault Economy provider เพื่อให้ปลั๊กอินอื่น (ร้านค้า, ฯลฯ) ใช้เงินชุดเดียวกัน
 * คลาสนี้อ้างอิง Vault โดยตรง จึงต้องเรียก register() เฉพาะเมื่อมีปลั๊กอิน Vault ติดตั้งอยู่
 */
public final class VortexEconomy implements Economy {

    private static final String NO_ACCOUNT = "ไม่พบบัญชีผู้เล่น";
    private static final String NO_BANK = "ระบบนี้ไม่รองรับธนาคาร";

    private final EconomyManager eco;

    private VortexEconomy(EconomyManager eco) {
        this.eco = eco;
    }

    public static void register(VortexCore plugin, EconomyManager eco) {
        plugin.getServer().getServicesManager()
                .register(Economy.class, new VortexEconomy(eco), plugin, ServicePriority.Highest);
    }

    // ------------------------------------------------------------ helpers

    private UUID id(String name) {
        return eco.findUuid(name);
    }

    private UUID id(OfflinePlayer p) {
        if (p == null) return null;
        eco.createAccount(p.getUniqueId(), p.getName());
        return p.getUniqueId();
    }

    private static boolean badAmount(double amount) {
        return Double.isNaN(amount) || Double.isInfinite(amount) || amount < 0;
    }

    private EconomyResponse fail(UUID id, String msg) {
        return new EconomyResponse(0, id == null ? 0 : eco.balance(id), ResponseType.FAILURE, msg);
    }

    private EconomyResponse deposit(UUID id, double amount) {
        if (id == null) return fail(null, NO_ACCOUNT);
        if (badAmount(amount)) return fail(id, "จำนวนเงินไม่ถูกต้อง");
        EconomyManager.Tx r = eco.deposit(id, Math.round(amount * 100.0));
        return switch (r) {
            case SUCCESS -> new EconomyResponse(amount, eco.balance(id), ResponseType.SUCCESS, null);
            case NO_ACCOUNT -> fail(id, NO_ACCOUNT);
            case MAX_BALANCE -> fail(id, "ยอดเงินเกินขีดจำกัดสูงสุด");
            case INSUFFICIENT, INVALID -> fail(id, "จำนวนเงินไม่ถูกต้อง");
        };
    }

    private EconomyResponse withdraw(UUID id, double amount) {
        if (id == null) return fail(null, NO_ACCOUNT);
        if (badAmount(amount)) return fail(id, "จำนวนเงินไม่ถูกต้อง");
        EconomyManager.Tx r = eco.withdraw(id, Math.round(amount * 100.0));
        return switch (r) {
            case SUCCESS -> new EconomyResponse(amount, eco.balance(id), ResponseType.SUCCESS, null);
            case NO_ACCOUNT -> fail(id, NO_ACCOUNT);
            case INSUFFICIENT -> fail(id, "เงินไม่พอ");
            case MAX_BALANCE, INVALID -> fail(id, "จำนวนเงินไม่ถูกต้อง");
        };
    }

    private double balanceOf(UUID id) {
        return id == null ? 0.0 : eco.balance(id);
    }

    private boolean hasAmount(UUID id, double amount) {
        return id != null && !badAmount(amount) && eco.has(id, Math.round(amount * 100.0));
    }

    private EconomyResponse noBank() {
        return new EconomyResponse(0, 0, ResponseType.NOT_IMPLEMENTED, NO_BANK);
    }

    // ------------------------------------------------------------ general

    @Override
    public boolean isEnabled() {
        return true;
    }

    @Override
    public String getName() {
        return "VortexCore";
    }

    @Override
    public boolean hasBankSupport() {
        return false;
    }

    @Override
    public int fractionalDigits() {
        return 2;
    }

    @Override
    public String format(double amount) {
        return eco.format(amount);
    }

    @Override
    public String currencyNamePlural() {
        return eco.plural();
    }

    @Override
    public String currencyNameSingular() {
        return eco.singular();
    }

    // ------------------------------------------------------------ accounts

    @Override
    @SuppressWarnings("deprecation")
    public boolean hasAccount(String playerName) {
        UUID id = id(playerName);
        return id != null && eco.hasAccount(id);
    }

    @Override
    public boolean hasAccount(OfflinePlayer player) {
        return player != null && eco.hasAccount(player.getUniqueId());
    }

    @Override
    @SuppressWarnings("deprecation")
    public boolean hasAccount(String playerName, String worldName) {
        return hasAccount(playerName);
    }

    @Override
    public boolean hasAccount(OfflinePlayer player, String worldName) {
        return hasAccount(player);
    }

    @Override
    @SuppressWarnings("deprecation")
    public boolean createPlayerAccount(String playerName) {
        UUID id = id(playerName);
        return id != null && eco.createAccount(id, playerName);
    }

    @Override
    public boolean createPlayerAccount(OfflinePlayer player) {
        return player != null && eco.createAccount(player.getUniqueId(), player.getName());
    }

    @Override
    @SuppressWarnings("deprecation")
    public boolean createPlayerAccount(String playerName, String worldName) {
        return createPlayerAccount(playerName);
    }

    @Override
    public boolean createPlayerAccount(OfflinePlayer player, String worldName) {
        return createPlayerAccount(player);
    }

    // ------------------------------------------------------------ balance / has

    @Override
    @SuppressWarnings("deprecation")
    public double getBalance(String playerName) {
        return balanceOf(id(playerName));
    }

    @Override
    public double getBalance(OfflinePlayer player) {
        return player == null ? 0.0 : balanceOf(player.getUniqueId());
    }

    @Override
    @SuppressWarnings("deprecation")
    public double getBalance(String playerName, String world) {
        return getBalance(playerName);
    }

    @Override
    public double getBalance(OfflinePlayer player, String world) {
        return getBalance(player);
    }

    @Override
    @SuppressWarnings("deprecation")
    public boolean has(String playerName, double amount) {
        return hasAmount(id(playerName), amount);
    }

    @Override
    public boolean has(OfflinePlayer player, double amount) {
        return player != null && hasAmount(player.getUniqueId(), amount);
    }

    @Override
    @SuppressWarnings("deprecation")
    public boolean has(String playerName, String worldName, double amount) {
        return has(playerName, amount);
    }

    @Override
    public boolean has(OfflinePlayer player, String worldName, double amount) {
        return has(player, amount);
    }

    // ------------------------------------------------------------ withdraw / deposit

    @Override
    @SuppressWarnings("deprecation")
    public EconomyResponse withdrawPlayer(String playerName, double amount) {
        return withdraw(id(playerName), amount);
    }

    @Override
    public EconomyResponse withdrawPlayer(OfflinePlayer player, double amount) {
        return withdraw(id(player), amount);
    }

    @Override
    @SuppressWarnings("deprecation")
    public EconomyResponse withdrawPlayer(String playerName, String worldName, double amount) {
        return withdrawPlayer(playerName, amount);
    }

    @Override
    public EconomyResponse withdrawPlayer(OfflinePlayer player, String worldName, double amount) {
        return withdrawPlayer(player, amount);
    }

    @Override
    @SuppressWarnings("deprecation")
    public EconomyResponse depositPlayer(String playerName, double amount) {
        return deposit(id(playerName), amount);
    }

    @Override
    public EconomyResponse depositPlayer(OfflinePlayer player, double amount) {
        return deposit(id(player), amount);
    }

    @Override
    @SuppressWarnings("deprecation")
    public EconomyResponse depositPlayer(String playerName, String worldName, double amount) {
        return depositPlayer(playerName, amount);
    }

    @Override
    public EconomyResponse depositPlayer(OfflinePlayer player, String worldName, double amount) {
        return depositPlayer(player, amount);
    }

    // ------------------------------------------------------------ banks (ไม่รองรับ)

    @Override
    @SuppressWarnings("deprecation")
    public EconomyResponse createBank(String name, String player) {
        return noBank();
    }

    @Override
    public EconomyResponse createBank(String name, OfflinePlayer player) {
        return noBank();
    }

    @Override
    public EconomyResponse deleteBank(String name) {
        return noBank();
    }

    @Override
    public EconomyResponse bankBalance(String name) {
        return noBank();
    }

    @Override
    public EconomyResponse bankHas(String name, double amount) {
        return noBank();
    }

    @Override
    public EconomyResponse bankWithdraw(String name, double amount) {
        return noBank();
    }

    @Override
    public EconomyResponse bankDeposit(String name, double amount) {
        return noBank();
    }

    @Override
    @SuppressWarnings("deprecation")
    public EconomyResponse isBankOwner(String name, String playerName) {
        return noBank();
    }

    @Override
    public EconomyResponse isBankOwner(String name, OfflinePlayer player) {
        return noBank();
    }

    @Override
    @SuppressWarnings("deprecation")
    public EconomyResponse isBankMember(String name, String playerName) {
        return noBank();
    }

    @Override
    public EconomyResponse isBankMember(String name, OfflinePlayer player) {
        return noBank();
    }

    @Override
    public List<String> getBanks() {
        return List.of();
    }
}
