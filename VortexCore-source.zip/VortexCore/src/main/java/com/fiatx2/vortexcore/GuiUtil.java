package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/** ตัวช่วยสร้างไอเทมสำหรับ GUI (ร้านค้า / ตลาดประมูล) */
final class GuiUtil {

    private GuiUtil() {}

    static Component line(String text, NamedTextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }

    static ItemStack icon(Material mat, Component name, List<Component> lore) {
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(name.decoration(TextDecoration.ITALIC, false));
        if (lore != null) meta.lore(lore);
        it.setItemMeta(meta);
        return it;
    }

    static String time(long millis) {
        long m = Math.max(0, millis / 60_000L);
        long h = m / 60;
        long d = h / 24;
        if (d > 0) return d + "d " + (h % 24) + "h";
        return h + "h " + (m % 60) + "m";
    }
}
