package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/** ตัวช่วยเช็คว่าอยู่ในโลกที่กำหนด (ค่าเริ่มต้น "smp") */
public final class Smp {

    private static String name = "smp";

    private Smp() {}

    public static void init(JavaPlugin plugin) {
        name = plugin.getConfig().getString("world-name", "smp");
    }

    public static String name() {
        return name;
    }

    /** โลก smp (อาจเป็น null ถ้ายังไม่โหลด/ชื่อผิด) */
    public static World world() {
        return Bukkit.getWorld(name);
    }

    public static boolean is(World w) {
        return w != null && w.getName().equals(name);
    }

    public static boolean is(Location l) {
        return l != null && is(l.getWorld());
    }

    public static boolean is(Entity e) {
        return e != null && is(e.getWorld());
    }

    public static void notHere(Player p) {
        p.sendMessage(Component.text("ใช้ได้เฉพาะในโลก " + name + " เท่านั้น", NamedTextColor.RED));
    }
}
