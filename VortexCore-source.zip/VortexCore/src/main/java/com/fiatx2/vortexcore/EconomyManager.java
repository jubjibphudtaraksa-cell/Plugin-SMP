package com.fiatx2.vortexcore;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * ระบบเงินหลักของเซิร์ฟเวอร์ เก็บใน economy.yml
 * เก็บยอดเป็น "สตางค์" (long) = จำนวนเงิน x 100 เพื่อเลี่ยงปัญหาทศนิยมของ double
 * ทุกเมธอดที่แก้ยอดเป็น synchronized จึงปลอดภัยแม้ปลั๊กอินอื่นเรียกผ่าน Vault จากหลาย thread
 */
public final class EconomyManager {

    public enum Tx { SUCCESS, NO_ACCOUNT, INSUFFICIENT, MAX_BALANCE, INVALID }

    private final VortexCore plugin;
    private final File file;
    private final Map<UUID, Long> balances = new HashMap<>();
    private final Map<UUID, String> names = new HashMap<>();
    private final Object ioLock = new Object();
    private boolean dirty; // guarded by this

    private String symbol = "$";
    private String singular = "Dollar";
    private String plural = "Dollars";
    private long startingCents = 50_000L;
    private long maxCents = Long.MAX_VALUE / 4;
    private long payMinCents = 100L;
    private double payTaxPercent = 0.0;

    public EconomyManager(VortexCore plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "economy.yml");
    }

    // ------------------------------------------------------------ settings / io

    public void load() {
        FileConfiguration cfg = plugin.getConfig();
        symbol = cfg.getString("economy.currency-symbol", "$");
        singular = cfg.getString("economy.currency-singular", "Dollar");
        plural = cfg.getString("economy.currency-plural", "Dollars");
        startingCents = Math.max(0L, Math.round(cfg.getDouble("economy.starting-balance", 500.0) * 100.0));
        double max = cfg.getDouble("economy.max-balance", 1_000_000_000_000.0);
        maxCents = max > 0 ? Math.round(max * 100.0) : Long.MAX_VALUE / 4;
        payMinCents = Math.max(1L, Math.round(cfg.getDouble("economy.pay.min", 1.0) * 100.0));
        payTaxPercent = Math.max(0.0, Math.min(100.0, cfg.getDouble("economy.pay.tax-percent", 0.0)));

        synchronized (this) {
            balances.clear();
            names.clear();
            if (!file.exists()) return;
            YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
            ConfigurationSection sec = yaml.getConfigurationSection("accounts");
            if (sec == null) return;
            for (String key : sec.getKeys(false)) {
                UUID id;
                try {
                    id = UUID.fromString(key);
                } catch (IllegalArgumentException e) {
                    continue; // ข้อมูล UUID เสีย ข้ามไป
                }
                balances.put(id, Math.max(0L, sec.getLong(key + ".balance", 0L)));
                String n = sec.getString(key + ".name");
                if (n != null) names.put(id, n);
            }
        }
        plugin.getLogger().info("Economy loaded: " + balances.size() + " accounts");
    }

    /** บันทึกเฉพาะเมื่อมีการเปลี่ยนแปลง; async = เขียนไฟล์นอก main thread */
    public void save(boolean async) {
        final Map<UUID, Long> b;
        final Map<UUID, String> n;
        synchronized (this) {
            if (!dirty) return;
            dirty = false;
            b = new HashMap<>(balances);
            n = new HashMap<>(names);
        }
        Runnable job = () -> write(b, n);
        if (async && plugin.isEnabled()) {
            Bukkit.getScheduler().runTaskAsynchronously(plugin, job);
        } else {
            job.run();
        }
    }

    private void write(Map<UUID, Long> b, Map<UUID, String> n) {
        YamlConfiguration yaml = new YamlConfiguration();
        for (Map.Entry<UUID, Long> e : b.entrySet()) {
            String base = "accounts." + e.getKey();
            yaml.set(base + ".balance", e.getValue());
            String name = n.get(e.getKey());
            if (name != null) yaml.set(base + ".name", name);
        }
        String data = yaml.saveToString();
        synchronized (ioLock) {
            try {
                Path target = file.toPath();
                Files.createDirectories(target.toAbsolutePath().getParent());
                Path tmp = target.resolveSibling("economy.yml.tmp");
                Files.writeString(tmp, data, StandardCharsets.UTF_8);
                Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ex) {
                plugin.getLogger().severe("Could not save economy.yml: " + ex.getMessage());
                synchronized (this) {
                    dirty = true; // ลองใหม่รอบหน้า
                }
            }
        }
    }

    public void startAutosave() {
        long minutes = Math.max(1L, plugin.getConfig().getLong("economy.autosave-minutes", 5L));
        long ticks = minutes * 60L * 20L;
        Bukkit.getScheduler().runTaskTimer(plugin, () -> save(true), ticks, ticks);
    }

    // ------------------------------------------------------------ accounts

    public synchronized boolean hasAccount(UUID id) {
        return balances.containsKey(id);
    }

    /** @return true ถ้าสร้างบัญชีใหม่ (ได้เงินเริ่มต้น) */
    public synchronized boolean createAccount(UUID id, String name) {
        if (name != null && !name.equals(names.put(id, name))) dirty = true;
        if (balances.containsKey(id)) return false;
        balances.put(id, Math.min(startingCents, maxCents));
        dirty = true;
        return true;
    }

    public synchronized long cents(UUID id) {
        return balances.getOrDefault(id, 0L);
    }

    public double balance(UUID id) {
        return cents(id) / 100.0;
    }

    public synchronized boolean has(UUID id, long cents) {
        return balances.getOrDefault(id, 0L) >= cents;
    }

    public synchronized Tx deposit(UUID id, long cents) {
        if (cents < 0) return Tx.INVALID;
        Long cur = balances.get(id);
        if (cur == null) return Tx.NO_ACCOUNT;
        if (cur + cents > maxCents) return Tx.MAX_BALANCE;
        balances.put(id, cur + cents);
        dirty = true;
        return Tx.SUCCESS;
    }

    public synchronized Tx withdraw(UUID id, long cents) {
        if (cents < 0) return Tx.INVALID;
        Long cur = balances.get(id);
        if (cur == null) return Tx.NO_ACCOUNT;
        if (cur < cents) return Tx.INSUFFICIENT;
        balances.put(id, cur - cents);
        dirty = true;
        return Tx.SUCCESS;
    }

    /** ตั้งยอดตรง ๆ (สร้างบัญชีให้ถ้ายังไม่มี) */
    public synchronized Tx set(UUID id, long cents) {
        if (cents < 0) return Tx.INVALID;
        if (cents > maxCents) return Tx.MAX_BALANCE;
        balances.put(id, cents);
        dirty = true;
        return Tx.SUCCESS;
    }

    public synchronized void reset(UUID id) {
        balances.put(id, Math.min(startingCents, maxCents));
        dirty = true;
    }

    /** โอนเงินแบบ atomic: ตัดจากผู้โอน debit สตางค์ / ผู้รับได้ credit สตางค์ (ส่วนต่าง = ภาษี) */
    public synchronized Tx transfer(UUID from, UUID to, long debit, long credit) {
        Long a = balances.get(from);
        Long b = balances.get(to);
        if (a == null || b == null) return Tx.NO_ACCOUNT;
        if (debit <= 0 || credit < 0 || credit > debit) return Tx.INVALID;
        if (a < debit) return Tx.INSUFFICIENT;
        if (b + credit > maxCents) return Tx.MAX_BALANCE;
        balances.put(from, a - debit);
        balances.put(to, b + credit);
        dirty = true;
        return Tx.SUCCESS;
    }

    /** อันดับคนรวย (มาก -> น้อย) */
    public synchronized List<Map.Entry<UUID, Long>> top() {
        List<Map.Entry<UUID, Long>> list = new ArrayList<>(balances.size());
        for (Map.Entry<UUID, Long> e : balances.entrySet()) {
            list.add(Map.entry(e.getKey(), e.getValue()));
        }
        list.sort((x, y) -> Long.compare(y.getValue(), x.getValue()));
        return list;
    }

    // ------------------------------------------------------------ lookup

    /** หา UUID จากชื่อ: ออนไลน์ -> ชื่อที่เคยบันทึก -> cache ของเซิร์ฟเวอร์ (ไม่ยิง web lookup) */
    public UUID findUuid(String name) {
        if (name == null) return null;
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return online.getUniqueId();
        synchronized (this) {
            for (Map.Entry<UUID, String> e : names.entrySet()) {
                if (e.getValue().equalsIgnoreCase(name)) return e.getKey();
            }
        }
        OfflinePlayer cached = Bukkit.getOfflinePlayerIfCached(name);
        return cached == null ? null : cached.getUniqueId();
    }

    public String nameOf(UUID id) {
        synchronized (this) {
            String n = names.get(id);
            if (n != null) return n;
        }
        String n = Bukkit.getOfflinePlayer(id).getName();
        return n != null ? n : id.toString().substring(0, 8);
    }

    // ------------------------------------------------------------ format / settings

    public String format(long cents) {
        return symbol + plain(cents);
    }

    public String format(double amount) {
        return format(Math.round(amount * 100.0));
    }

    public String plain(long cents) {
        return String.format(Locale.US, "%,.2f", cents / 100.0);
    }

    public String plain(UUID id) {
        return plain(cents(id));
    }

    public String symbol() { return symbol; }

    public String singular() { return singular; }

    public String plural() { return plural; }

    public long payMinCents() { return payMinCents; }

    public double payTaxPercent() { return payTaxPercent; }
}
