package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** /lobby - วาปไปจุดสปอนของโลก lobby (ค่าเริ่มต้น "EPIC") ใช้ได้ทุกโลก */
public final class LobbyModule implements CommandExecutor {

    private final VortexCore plugin;
    private final TpaModule tpa;
    private final Set<UUID> counting = new HashSet<>();

    public LobbyModule(VortexCore plugin, TpaModule tpa) {
        this.plugin = plugin;
        this.tpa = tpa;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args) {
        if (!(s instanceof Player p)) {
            s.sendMessage("เฉพาะผู้เล่นเท่านั้น");
            return true;
        }
        if (tpa.isTagged(p)) {
            p.sendMessage(Component.text("ติด Combat ใช้ /lobby ไม่ได้", NamedTextColor.RED));
            return true;
        }
        String worldName = plugin.getConfig().getString("lobby-world", "EPIC");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            p.sendMessage(Component.text("ไม่พบโลก " + worldName, NamedTextColor.RED));
            return true;
        }
        UUID pid = p.getUniqueId();
        if (!counting.add(pid)) {
            p.sendMessage(Component.text("กำลังนับถอยหลังอยู่แล้ว", NamedTextColor.RED));
            return true;
        }

        Location start = p.getLocation();
        Location base = world.getSpawnLocation();
        Location target = new Location(world, base.getBlockX() + 0.5, base.getBlockY(),
                base.getBlockZ() + 0.5, base.getYaw(), base.getPitch());
        p.sendMessage(Component.text("อย่าขยับ! กำลังวาปไป Lobby...", NamedTextColor.YELLOW));

        new BukkitRunnable() {
            int sec = 5;

            @Override
            public void run() {
                if (!p.isOnline()) {
                    stop();
                    return;
                }
                Location now = p.getLocation();
                if (!now.getWorld().equals(start.getWorld()) || now.distanceSquared(start) > 0.1) {
                    p.sendMessage(Component.text("ยกเลิกการวาป เพราะคุณขยับ", NamedTextColor.RED));
                    stop();
                    return;
                }
                if (tpa.isTagged(p)) {
                    p.sendMessage(Component.text("ยกเลิกการวาป เพราะติด Combat", NamedTextColor.RED));
                    stop();
                    return;
                }
                if (sec > 0) {
                    p.sendMessage(Component.text(String.valueOf(sec), NamedTextColor.YELLOW, TextDecoration.BOLD));
                    p.playSound(now, Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.2f);
                    sec--;
                    return;
                }
                stop();
                p.teleportAsync(target);
            }

            private void stop() {
                counting.remove(pid);
                cancel();
            }
        }.runTaskTimer(plugin, 0L, 20L);
        return true;
    }
}
