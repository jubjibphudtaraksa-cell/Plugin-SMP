package com.fiatx2.vortexcore;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * ราคารับซื้อของ /sell — อ่านจาก plugins/VortexCore/sell-prices.yml
 * (แยกออกมาจาก shop.yml เดิม เพราะ /shop แบบ DojoShop เป็นซื้ออย่างเดียว)
 * ราคารับซื้อจะไม่เกินราคาซื้อจาก /shop ของไอเทมเดียวกัน (กันปั๊มเงิน)
 */
public final class SellPrices {

    private static final List<String> DEFAULT_BLOCKED = List.of(
            "BEDROCK", "BARRIER", "LIGHT", "STRUCTURE_BLOCK", "STRUCTURE_VOID", "JIGSAW", "DEBUG_STICK",
            "KNOWLEDGE_BOOK", "SPAWNER", "TRIAL_SPAWNER", "VAULT", "END_PORTAL_FRAME", "REINFORCED_DEEPSLATE",
            "COMMAND_BLOCK", "CHAIN_COMMAND_BLOCK", "REPEATING_COMMAND_BLOCK", "PETRIFIED_OAK_SLAB",
            "NETHER_STAR", "ELYTRA", "DRAGON_EGG", "ENCHANTED_GOLDEN_APPLE", "BEACON", "TRIDENT", "MACE",
            "HEAVY_CORE", "CONDUIT", "HEART_OF_THE_SEA", "TOTEM_OF_UNDYING", "OMINOUS_TRIAL_KEY", "TRIAL_KEY");

    /** อาวุธและเกราะ: ไม่รับซื้อโดยอัตโนมัติ (ยกเว้นระบุราคาใน sell-prices.yml) */
    private static final List<String> BLOCKED_SUFFIX = List.of(
            "_SWORD", "_HELMET", "_CHESTPLATE", "_LEGGINGS", "_BOOTS");
    private static final Set<String> BLOCKED_EXACT = Set.of(
            "BOW", "CROSSBOW", "SHIELD", "TRIDENT", "MACE", "TURTLE_HELMET", "WOLF_ARMOR");

    private static boolean weaponOrArmor(String n) {
        if (BLOCKED_EXACT.contains(n)) return true;
        for (String suf : BLOCKED_SUFFIX) if (n.endsWith(suf)) return true;
        return n.endsWith("_HORSE_ARMOR");
    }

    private final VortexCore plugin;
    private final ShopModule shop;
    private final Map<Material, Long> prices = new HashMap<>();
    private final Set<String> blocked = new HashSet<>();
    private long defaultSell = 0;

    public SellPrices(VortexCore plugin, ShopModule shop) {
        this.plugin = plugin;
        this.shop = shop;
        load();
    }

    private static long cents(double v) {
        return Math.round(v * 100.0);
    }

    public void load() {
        prices.clear();
        blocked.clear();
        defaultSell = cents(plugin.getConfig().getDouble("sell.default-price", 0.25));
        blocked.addAll(DEFAULT_BLOCKED);
        for (String b : plugin.getConfig().getStringList("sell.blocked")) blocked.add(b.toUpperCase());

        File f = new File(plugin.getDataFolder(), "sell-prices.yml");
        if (!f.exists()) plugin.saveResource("sell-prices.yml", false);
        ConfigurationSection sp = YamlConfiguration.loadConfiguration(f).getConfigurationSection("sell-prices");
        if (sp != null) {
            for (String mk : sp.getKeys(false)) {
                Material m = Material.matchMaterial(mk);
                long v = cents(sp.getDouble(mk, 0));
                if (m == null || !m.isItem() || v <= 0) {
                    plugin.getLogger().warning("sell-prices.yml: ข้าม '" + mk + "'");
                    continue;
                }
                Long cap = shop.buyPrice(m);
                prices.put(m, cap != null ? Math.min(v, cap) : v);
            }
        }
    }

    /** ราคารับซื้อต่อชิ้น (cents) สำหรับ /sell — 0 ถ้าไม่รับซื้อ */
    public long sellPrice(Material m) {
        Long v = prices.get(m);
        if (v != null) return v;
        if (defaultSell <= 0 || !m.isItem() || m.isAir() || m.name().startsWith("LEGACY_")) return 0;
        String n = m.name();
        if (blocked.contains(n) || n.endsWith("_SPAWN_EGG") || n.startsWith("NETHERITE_") || weaponOrArmor(n)) return 0;
        Long cap = shop.buyPrice(m);
        return cap != null ? Math.min(defaultSell, cap) : defaultSell;
    }
}
