package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Boss;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;

/** เคลียร์ไอเทม/มอนสเตอร์ เฉพาะในโลก smp */
public final class AutoClearModule implements CommandExecutor {

    private final VortexCore plugin;
    private int interval;
    private int seconds;

    public AutoClearModule(VortexCore plugin) {
        this.plugin = plugin;
    }

    public void start() {
        interval = Math.max(30, plugin.getConfig().getInt("interval-seconds", 600));
        seconds = interval;

        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            seconds--;
            if (seconds == 30 || (seconds >= 1 && seconds <= 10)) {
                broadcast("จะเคลียร์ไอเทมและมอนสเตอร์ใน " + seconds + " วินาที!", NamedTextColor.YELLOW);
            }
            if (seconds <= 0) {
                runClear();
                seconds = interval;
            }
        }, 20L, 20L);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("autoclear.clearworld")) {
            sender.sendMessage(Component.text("คุณไม่มีสิทธิ์ใช้คำสั่งนี้", NamedTextColor.RED));
            return true;
        }
        if (sender instanceof Player p && !Smp.is(p.getWorld())) {
            Smp.notHere(p);
            return true;
        }
        runClear();
        seconds = interval;
        return true;
    }

    private void runClear() {
        int items = 0, mobs = 0;
        for (World world : Smp.worlds()) {
            for (Entity e : world.getEntities()) {
                if (e instanceof Item) {
                    e.remove();
                    items++;
                } else if (e instanceof Enemy && !(e instanceof Boss) && e.customName() == null) {
                    e.remove();
                    mobs++;
                }
            }
        }
        broadcast("เคลียร์แล้ว! ไอเทม " + items + " ชิ้น, มอนสเตอร์ " + mobs + " ตัว", NamedTextColor.GREEN);
    }

    /** ส่งข้อความให้เฉพาะผู้เล่นในโลก smp / nether / end */
    private void broadcast(String msg, NamedTextColor color) {
        Component c = Component.text("[AutoClear] ", NamedTextColor.GOLD)
                .append(Component.text(msg, color));
        for (World world : Smp.worlds()) {
            for (Player p : world.getPlayers()) p.sendMessage(c);
        }
    }
}
