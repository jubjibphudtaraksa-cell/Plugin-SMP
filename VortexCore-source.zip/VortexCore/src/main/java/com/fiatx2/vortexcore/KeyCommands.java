package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.SoundCategory;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class KeyCommands implements CommandExecutor, TabCompleter {

    private static final String ADMIN = "keycompass.admin";
    private static final Component PREFIX = Component.text("[KeyCompass] ", NamedTextColor.GOLD);

    private final VortexCore plugin;
    private final Map<UUID, Long> cooldownUntil = new HashMap<>();

    public KeyCommands(VortexCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);

        if (name.equals("key")) {
            handleKey(sender, args);
            return true;
        }

        // คำสั่งที่เหลือเป็นของ OP ทั้งหมด
        if (!sender.hasPermission(ADMIN)) {
            send(sender, "คำสั่งนี้สำหรับ OP เท่านั้น", NamedTextColor.RED);
            return true;
        }

        switch (name) {
            case "addkey" -> handleAdd(sender, args);
            case "dekey" -> handleDelete(sender, args);
            case "deakey" -> handleDeleteAll(sender);
            case "showkey" -> handleShow(sender);
            default -> { }
        }
        return true;
    }

    // ---------------------------------------------------------------- /key

    private void handleKey(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            send(sender, "คำสั่งนี้ใช้ได้เฉพาะผู้เล่นในเกม", NamedTextColor.RED);
            return;
        }
        if (!Smp.is(player.getWorld())) {
            Smp.notHere(player);
            return;
        }
        if (args.length != 1) {
            send(player, "วิธีใช้: /key <คีย์>", NamedTextColor.YELLOW);
            return;
        }

        long now = System.currentTimeMillis();
        Long until = cooldownUntil.get(player.getUniqueId());
        if (until != null && until > now) {
            long seconds = (until - now + 999) / 1000;
            send(player, "กรุณารออีก " + seconds + " วินาทีก่อนลองใส่คีย์ใหม่", NamedTextColor.RED);
            return;
        }

        switch (plugin.keys().redeem(player, args[0])) {
            case SUCCESS -> giveCompass(player);
            case ALREADY_USED -> {
                startCooldown(player, now);
                player.playSound(player.getLocation(), "entity.villager.no", SoundCategory.PLAYERS, 1.0f, 1.0f);
                send(player, "คีย์นี้ถูกใช้ไปแล้ว", NamedTextColor.RED);
            }
            case INVALID -> {
                startCooldown(player, now);
                player.playSound(player.getLocation(), "entity.villager.no", SoundCategory.PLAYERS, 1.0f, 1.0f);
                send(player, "คีย์ไม่ถูกต้อง", NamedTextColor.RED);
            }
        }
    }

    private void giveCompass(Player player) {
        ItemStack compass = plugin.magic().create();
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(compass);

        boolean dropped = !leftover.isEmpty();
        for (ItemStack item : leftover.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), item);
        }

        player.playSound(player.getLocation(), "entity.player.levelup", SoundCategory.PLAYERS, 1.0f, 1.0f);
        send(player, "คีย์ถูกต้อง! คุณได้รับ เข็มทิศวิเศษ", NamedTextColor.GREEN);
        if (dropped) {
            send(player, "กระเป๋าของคุณเต็ม เข็มทิศจึงถูกดรอปไว้ที่พื้น", NamedTextColor.YELLOW);
        }
    }

    private void startCooldown(Player player, long now) {
        long seconds = plugin.getConfig().getLong("wrong-key-cooldown-seconds", 3L);
        if (seconds <= 0) {
            return;
        }
        cooldownUntil.values().removeIf(t -> t <= now);
        cooldownUntil.put(player.getUniqueId(), now + seconds * 1000L);
    }

    // ------------------------------------------------------------- admin

    private void handleAdd(CommandSender sender, String[] args) {
        if (args.length != 1) {
            send(sender, "วิธีใช้: /addkey <คีย์>", NamedTextColor.YELLOW);
            return;
        }
        if (plugin.keys().add(args[0])) {
            send(sender, "เพิ่มคีย์ '" + args[0] + "' เรียบร้อย", NamedTextColor.GREEN);
        } else {
            send(sender, "มีคีย์ '" + args[0] + "' อยู่แล้ว", NamedTextColor.RED);
        }
    }

    private void handleShow(CommandSender sender) {
        Collection<KeyManager.KeyEntry> all = plugin.keys().all();
        if (all.isEmpty()) {
            send(sender, "ยังไม่มีคีย์ในระบบ", NamedTextColor.GRAY);
            return;
        }
        send(sender, "คีย์ทั้งหมด (" + all.size() + ")", NamedTextColor.AQUA);
        int index = 1;
        for (KeyManager.KeyEntry entry : all) {
            sender.sendMessage(keyLine(index++, entry));
        }
    }

    private void handleDelete(CommandSender sender, String[] args) {
        if (args.length == 0) {
            Collection<KeyManager.KeyEntry> all = plugin.keys().all();
            if (all.isEmpty()) {
                send(sender, "ยังไม่มีคีย์ในระบบ", NamedTextColor.GRAY);
                return;
            }
            send(sender, "เลือกคีย์ที่จะลบ (คลิก [ลบ] หรือพิมพ์ /dekey <คีย์>)", NamedTextColor.AQUA);
            int index = 1;
            for (KeyManager.KeyEntry entry : all) {
                Component delete = Component.text("  [ลบ]", NamedTextColor.RED)
                        .clickEvent(ClickEvent.runCommand("/dekey " + entry.key()))
                        .hoverEvent(HoverEvent.showText(
                                Component.text("คลิกเพื่อลบคีย์ '" + entry.key() + "'", NamedTextColor.RED)));
                sender.sendMessage(keyLine(index++, entry).append(delete));
            }
            return;
        }
        if (args.length != 1) {
            send(sender, "วิธีใช้: /dekey [คีย์]", NamedTextColor.YELLOW);
            return;
        }
        if (plugin.keys().remove(args[0])) {
            send(sender, "ลบคีย์ '" + args[0] + "' แล้ว", NamedTextColor.GREEN);
        } else {
            send(sender, "ไม่พบคีย์ '" + args[0] + "'", NamedTextColor.RED);
        }
    }

    private void handleDeleteAll(CommandSender sender) {
        int count = plugin.keys().clear();
        send(sender, "ลบคีย์ทั้งหมดแล้ว (" + count + " คีย์)", NamedTextColor.GREEN);
    }

    // ----------------------------------------------------------- helpers

    private Component keyLine(int index, KeyManager.KeyEntry entry) {
        Component status = entry.isUsed()
                ? Component.text(" - ใช้แล้วโดย " + (entry.usedByName() == null ? "?" : entry.usedByName()),
                        NamedTextColor.RED)
                : Component.text(" - ว่าง", NamedTextColor.GREEN);
        return Component.text(index + ". ", NamedTextColor.GRAY)
                .append(Component.text(entry.key(), NamedTextColor.WHITE))
                .append(status);
    }

    private void send(CommandSender sender, String text, TextColor color) {
        sender.sendMessage(PREFIX.append(Component.text(text, color)));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        // /key ไม่แนะนำคีย์ให้ เพราะเป็นความลับ
        if (command.getName().equalsIgnoreCase("dekey") && args.length == 1 && sender.hasPermission(ADMIN)) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            return plugin.keys().all().stream()
                    .map(KeyManager.KeyEntry::key)
                    .filter(k -> k.toLowerCase(Locale.ROOT).startsWith(prefix))
                    .toList();
        }
        return List.of();
    }
}
