package com.fiatx2.vortexcore;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * เก็บคีย์ทั้งหมดไว้ใน keys.yml
 * คีย์ 1 อันใช้ได้แค่ 1 คน: พอมีคนใส่แล้วจะถูกผูกกับคนนั้นและใช้ซ้ำไม่ได้
 */
public final class KeyManager {

    public enum Result { SUCCESS, INVALID, ALREADY_USED }

    public record KeyEntry(String key, UUID usedBy, String usedByName) {
        public boolean isUsed() {
            return usedBy != null;
        }
    }

    private final VortexCore plugin;
    private final File file;
    private final Map<String, KeyEntry> keys = new LinkedHashMap<>();

    public KeyManager(VortexCore plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "keys.yml");
    }

    public void load() {
        keys.clear();
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        for (Map<?, ?> map : yaml.getMapList("keys")) {
            Object rawKey = map.get("key");
            if (rawKey == null) {
                continue;
            }
            String key = String.valueOf(rawKey);

            UUID usedBy = null;
            Object rawUuid = map.get("used-by");
            if (rawUuid != null) {
                try {
                    usedBy = UUID.fromString(String.valueOf(rawUuid));
                } catch (IllegalArgumentException ignored) {
                    // ข้อมูล UUID เสีย ถือว่ายังไม่ถูกใช้
                }
            }
            Object rawName = map.get("used-by-name");
            String usedByName = rawName == null ? null : String.valueOf(rawName);

            keys.put(key, new KeyEntry(key, usedBy, usedByName));
        }
    }

    public void save() {
        List<Map<String, Object>> list = new ArrayList<>();
        for (KeyEntry entry : keys.values()) {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("key", entry.key());
            if (entry.usedBy() != null) {
                map.put("used-by", entry.usedBy().toString());
                if (entry.usedByName() != null) {
                    map.put("used-by-name", entry.usedByName());
                }
            }
            list.add(map);
        }
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("keys", list);
        try {
            plugin.getDataFolder().mkdirs();
            yaml.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save keys.yml: " + e.getMessage());
        }
    }

    public Collection<KeyEntry> all() {
        return List.copyOf(keys.values());
    }

    /** @return false ถ้ามีคีย์นี้อยู่แล้ว */
    public boolean add(String key) {
        if (keys.containsKey(key)) {
            return false;
        }
        keys.put(key, new KeyEntry(key, null, null));
        save();
        return true;
    }

    /** @return false ถ้าไม่มีคีย์นี้ */
    public boolean remove(String key) {
        if (keys.remove(key) == null) {
            return false;
        }
        save();
        return true;
    }

    /** @return จำนวนคีย์ที่ถูกลบ */
    public int clear() {
        int count = keys.size();
        keys.clear();
        save();
        return count;
    }

    public Result redeem(Player player, String key) {
        KeyEntry entry = keys.get(key);
        if (entry == null) {
            return Result.INVALID;
        }
        if (entry.isUsed()) {
            return Result.ALREADY_USED;
        }
        keys.put(key, new KeyEntry(key, player.getUniqueId(), player.getName()));
        save();
        plugin.getLogger().info(player.getName() + " redeemed key '" + key + "'");
        return Result.SUCCESS;
    }
}
