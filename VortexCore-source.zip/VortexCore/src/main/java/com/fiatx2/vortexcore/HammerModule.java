package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.inventory.PrepareGrindstoneEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.RayTraceResult;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Map;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * เครื่องมือเนเธอร์ไรต์ 3x3 (ย้ายมาจาก ShopModule เดิม) — ซื้อได้จาก /shop ไอเทมที่ใส่ special: hammer
 * คราฟ/ซ่อม/ใส่เอนชานท์ไม่ได้ ใช้ได้ตามจำนวนครั้งที่กำหนด
 * (ใช้ key เดิม "hammer_uses" ค้อนที่ผู้เล่นมีอยู่แล้วจึงยังใช้งานต่อได้)
 */
public final class HammerModule implements Listener {

    private static final int FELLER_MAX_LOGS = 300;
    private static final int FELLER_MAX_RADIUS = 12;

    private final NamespacedKey usesKey;
    private final NamespacedKey modeKey;
    private final Set<UUID> breaking = new HashSet<>();

    public HammerModule(VortexCore plugin) {
        this.usesKey = new NamespacedKey(plugin, "hammer_uses");
        this.modeKey = new NamespacedKey(plugin, "hammer_mode");
    }

    private static Component c(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    /** ค้อน 3x3 แบบเดิม (ไม่มีเอนชานท์) */
    public ItemStack make(Material mat, String name, int uses) {
        return make(mat, name, uses, null, null);
    }

    /**
     * @param mode    null = ขุด 3x3, "feller" = ตัดไม้ทั้งต้น
     * @param variant "silk" / "fortune" (ใช้กับพิคแอ็กซ์) หรือ null; มีผลกับเอนชานท์ที่ใส่ให้
     */
    public ItemStack make(Material mat, String name, int uses, String mode, String variant) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.displayName(c(name != null ? name : "&b&l3x3 " + mat.name()));
        m.setUnbreakable(true);
        m.getPersistentDataContainer().set(usesKey, PersistentDataType.INTEGER, uses);
        if (mode != null) m.getPersistentDataContainer().set(modeKey, PersistentDataType.STRING, mode);
        for (Map.Entry<Enchantment, Integer> en : enchants(mat, mode, variant).entrySet())
            m.addEnchant(en.getKey(), en.getValue(), true);
        it.setItemMeta(m);
        updateLore(it, uses);
        return it;
    }

    /** เอนชานท์ครบเลเวลสูงสุดตามชนิดเครื่องมือ */
    private static Map<Enchantment, Integer> enchants(Material mat, String mode, String variant) {
        Map<Enchantment, Integer> e = new java.util.LinkedHashMap<>();
        e.put(Enchantment.EFFICIENCY, 5);
        e.put(Enchantment.UNBREAKING, 3);
        e.put(Enchantment.MENDING, 1);
        String n = mat.name();
        if (n.endsWith("_PICKAXE")) {
            if ("silk".equalsIgnoreCase(variant)) e.put(Enchantment.SILK_TOUCH, 1);
            else e.put(Enchantment.FORTUNE, 3);
        } else if (n.endsWith("_AXE")) {
            e.put(Enchantment.SHARPNESS, 5);
            e.put(Enchantment.SILK_TOUCH, 1);
        } else if (n.endsWith("_SHOVEL")) {
            e.put(Enchantment.SILK_TOUCH, 1);
        }
        return e;
    }

    private String modeOf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(modeKey, PersistentDataType.STRING);
    }

    private void updateLore(ItemStack it, int uses) {
        ItemMeta m = it.getItemMeta();
        m.getPersistentDataContainer().set(usesKey, PersistentDataType.INTEGER, uses);
        boolean feller = "feller".equals(m.getPersistentDataContainer().get(modeKey, PersistentDataType.STRING));
        m.lore(List.of(
                c(feller ? "&7ตัดไม้ &fทั้งต้น &7ในครั้งเดียว &8(เนเธอร์ไรต์)"
                        : "&7ขุดทีละ &f3x3 &7บล็อก &8(เนเธอร์ไรต์)"),
                c("&7ใช้ได้อีก: &e" + uses + " &7ครั้ง"),
                c(feller ? "&8นั่งยอง (Shift) = ตัดท่อนเดียว ไม่เสียจำนวนครั้ง"
                        : "&8นั่งยอง (Shift) = ขุดบล็อกเดียว ไม่เสียจำนวนครั้ง"),
                c("&cคราฟไม่ได้ ซื้อได้อย่างเดียว")));
        it.setItemMeta(m);
    }

    private Integer getUses(ItemStack it) {
        if (it == null || !it.getType().name().startsWith("NETHERITE_") || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(usesKey, PersistentDataType.INTEGER);
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (breaking.contains(p.getUniqueId())) return;
        ItemStack tool = p.getInventory().getItemInMainHand();
        Integer uses = getUses(tool);
        if (uses == null) return;
        if (p.isSneaking()) return;

        if ("feller".equals(modeOf(tool))) {
            fell(p, e.getBlock(), tool, uses);
            return;
        }

        Block center = e.getBlock();
        RayTraceResult r = p.rayTraceBlocks(6);
        BlockFace face = (r != null && center.equals(r.getHitBlock()) && r.getHitBlockFace() != null)
                ? r.getHitBlockFace() : p.getFacing().getOppositeFace();

        breaking.add(p.getUniqueId());
        try {
            for (int a = -1; a <= 1; a++) {
                for (int b = -1; b <= 1; b++) {
                    if (a == 0 && b == 0) continue;
                    Block t = face.getModX() != 0 ? center.getRelative(0, a, b)
                            : face.getModY() != 0 ? center.getRelative(a, 0, b)
                            : center.getRelative(a, b, 0);
                    Material type = t.getType();
                    if (type.isAir() || t.isLiquid() || type.getHardness() < 0) continue;
                    if (t.getDestroySpeed(tool) <= 1f) continue;
                    BlockBreakEvent be = new BlockBreakEvent(t, p);
                    if (!be.callEvent()) continue;
                    if (be.isDropItems()) t.breakNaturally(tool);
                    else t.setType(Material.AIR);
                }
            }
        } finally {
            breaking.remove(p.getUniqueId());
        }

        int left = uses - 1;
        if (left <= 0) {
            p.getInventory().setItemInMainHand(null);
            p.playSound(p.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 1f);
            p.sendMessage(c("&6[Shop] &cเครื่องมือ 3x3 ของคุณหมดอายุการใช้งานแล้ว"));
        } else {
            updateLore(tool, left);
            p.getInventory().setItemInMainHand(tool);
            if (left <= 10) p.sendActionBar(c("&cเหลืออีก " + left + " ครั้ง"));
        }
    }

    private static boolean isLeaves(Material t) {
        return Tag.LEAVES.isTagged(t) || t == Material.NETHER_WART_BLOCK || t == Material.WARPED_WART_BLOCK;
    }

    /** ตัดไม้ทั้งต้น: flood-fill ท่อนไม้ที่ติดกัน (ต้องมีใบไม้ติดกับต้น กันพังบ้านที่สร้างจากไม้ล้วน) */
    private void fell(Player p, Block origin, ItemStack tool, int uses) {
        if (!Tag.LOGS.isTagged(origin.getType())) return;

        Set<Block> logs = new HashSet<>();
        ArrayDeque<Block> queue = new ArrayDeque<>();
        logs.add(origin);
        queue.add(origin);
        boolean hasLeaves = false;
        while (!queue.isEmpty() && logs.size() < FELLER_MAX_LOGS) {
            Block b = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        Block n = b.getRelative(dx, dy, dz);
                        Material t = n.getType();
                        if (isLeaves(t)) { hasLeaves = true; continue; }
                        if (!Tag.LOGS.isTagged(t) || logs.contains(n)) continue;
                        if (Math.abs(n.getX() - origin.getX()) > FELLER_MAX_RADIUS
                                || Math.abs(n.getZ() - origin.getZ()) > FELLER_MAX_RADIUS) continue;
                        if (logs.size() >= FELLER_MAX_LOGS) continue;
                        logs.add(n);
                        queue.add(n);
                    }
                }
            }
        }
        if (!hasLeaves) return; // ไม่ใช่ต้นไม้ -> ตัดท่อนเดียวตามปกติ ไม่เสียจำนวนครั้ง

        breaking.add(p.getUniqueId());
        try {
            for (Block t : logs) {
                if (t.equals(origin)) continue; // ท่อนที่ผู้เล่นตีอยู่ ระบบจะทำลายเอง
                BlockBreakEvent be = new BlockBreakEvent(t, p);
                if (!be.callEvent()) continue;
                if (be.isDropItems()) t.breakNaturally(tool);
                else t.setType(Material.AIR);
            }
        } finally {
            breaking.remove(p.getUniqueId());
        }

        int left = uses - 1;
        if (left <= 0) {
            p.getInventory().setItemInMainHand(null);
            p.playSound(p.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 1f);
            p.sendMessage(c("&6[Shop] &cขวานตัดทั้งต้นของคุณหมดอายุการใช้งานแล้ว"));
        } else {
            updateLore(tool, left);
            p.getInventory().setItemInMainHand(tool);
            if (left <= 10) p.sendActionBar(c("&cเหลืออีก " + left + " ครั้ง"));
        }
    }

    @EventHandler
    public void onAnvil(PrepareAnvilEvent e) {
        for (ItemStack i : e.getInventory().getContents())
            if (getUses(i) != null) { e.setResult(null); return; }
    }

    @EventHandler
    public void onCraft(PrepareItemCraftEvent e) {
        for (ItemStack i : e.getInventory().getMatrix())
            if (getUses(i) != null) { e.getInventory().setResult(null); return; }
    }

    @EventHandler
    public void onGrind(PrepareGrindstoneEvent e) {
        for (ItemStack i : e.getInventory().getContents())
            if (getUses(i) != null) { e.setResult(null); return; }
    }
}
