package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * /sell — เมนูขายของ: ใส่ไอเทมลงในช่องว่าง แล้วกดปุ่มขาย
 * ราคาอ้างอิงจาก sell-prices.yml (จำกัดไม่ให้เกินราคาซื้อใน /shop)
 * ไอเทมที่ไม่รับซื้อจะถูกคืนเมื่อปิดเมนู
 */
public final class SellModule implements CommandExecutor, Listener {

    private static final int SIZE = 54;
    private static final int SLOTS = 45;
    private static final int SELL_SLOT = 49;

    private static final class Holder implements InventoryHolder {
        Inventory inv;

        @Override
        public @NotNull Inventory getInventory() { return inv; }
    }

    private final VortexCore plugin;
    private final EconomyManager eco;
    private final SellPrices shop;

    public SellModule(VortexCore plugin, EconomyManager eco, SellPrices shop) {
        this.plugin = plugin;
        this.eco = eco;
        this.shop = shop;
    }

    /** ปิดเมนูที่เปิดค้างอยู่ทั้งหมด (คืนของให้ผู้เล่น) ตอนปิดปลั๊กอิน */
    public void shutdown() {
        for (Player p : new ArrayList<>(Bukkit.getOnlinePlayers())) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof Holder) p.closeInventory();
        }
    }

    // ------------------------------------------------------------ command

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("ใช้ได้เฉพาะผู้เล่น");
            return true;
        }
        if (!Smp.is(p)) {
            Smp.notHere(p);
            return true;
        }
        open(p);
        return true;
    }

    // ------------------------------------------------------------ GUI

    private void open(Player p) {
        Holder h = new Holder();
        Inventory inv = Bukkit.createInventory(h, SIZE, Component.text("Sell"));
        h.inv = inv;
        ItemStack pane = GuiUtil.icon(Material.GRAY_STAINED_GLASS_PANE, Component.text(" "), null);
        for (int i = SLOTS; i < SIZE; i++) inv.setItem(i, pane);
        refresh(inv);
        p.openInventory(inv);
        p.sendMessage(Component.text("วางไอเทมที่ต้องการขายลงในช่องด้านบน แล้วกดปุ่มสีเขียว", NamedTextColor.GRAY));
    }

    private boolean sellable(ItemStack it) {
        return it != null && it.getType() != Material.AIR && !it.hasItemMeta() && shop.sellPrice(it.getType()) > 0;
    }

    private void refresh(Inventory inv) {
        long total = 0;
        int count = 0;
        for (int i = 0; i < SLOTS; i++) {
            ItemStack it = inv.getItem(i);
            if (!sellable(it)) continue;
            total += shop.sellPrice(it.getType()) * it.getAmount();
            count += it.getAmount();
        }
        List<Component> lore = new ArrayList<>();
        lore.add(GuiUtil.line("Items: " + count, NamedTextColor.GRAY));
        lore.add(GuiUtil.line("Total: " + eco.format(total), NamedTextColor.GOLD));
        lore.add(GuiUtil.line("Click to sell", NamedTextColor.GREEN));
        inv.setItem(SELL_SLOT, GuiUtil.icon(count > 0 ? Material.LIME_WOOL : Material.RED_WOOL,
                Component.text(count > 0 ? "Sell" : "Nothing to sell", count > 0 ? NamedTextColor.GREEN : NamedTextColor.RED), lore));
    }

    private void sell(Player p, Inventory inv) {
        long total = 0;
        int count = 0;
        List<Integer> slots = new ArrayList<>();
        for (int i = 0; i < SLOTS; i++) {
            ItemStack it = inv.getItem(i);
            if (!sellable(it)) continue;
            total += shop.sellPrice(it.getType()) * it.getAmount();
            count += it.getAmount();
            slots.add(i);
        }
        if (count == 0) {
            p.sendActionBar(Component.text("ไม่มีไอเทมที่ขายได้ในเมนู", NamedTextColor.RED));
            return;
        }
        if (eco.deposit(p.getUniqueId(), total) != EconomyManager.Tx.SUCCESS) {
            p.sendActionBar(Component.text("ขายไม่สำเร็จ (เงินเต็มเพดาน)", NamedTextColor.RED));
            return;
        }
        for (int i : slots) inv.setItem(i, null);
        refresh(inv);
        p.sendActionBar(Component.text("Sold " + count + " items for " + eco.format(total), NamedTextColor.GOLD));
    }

    // ------------------------------------------------------------ events

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder h)) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Inventory top = h.inv;
        if (e.getClickedInventory() == top && e.getSlot() >= SLOTS) {
            e.setCancelled(true);
            if (e.getSlot() == SELL_SLOT) sell(p, top);
            return;
        }
        // คลิกในช่องวางของ / กระเป๋าผู้เล่น: ปล่อยให้ทำงานตามปกติ แล้วคำนวณราคาใหม่
        Bukkit.getScheduler().runTask(plugin, () -> refresh(top));
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder h)) return;
        for (int raw : e.getRawSlots()) {
            if (raw >= SLOTS && raw < SIZE) {
                e.setCancelled(true);
                return;
            }
        }
        Bukkit.getScheduler().runTask(plugin, () -> refresh(h.inv));
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder h)) return;
        if (!(e.getPlayer() instanceof Player p)) return;
        // คืนไอเทมที่เหลือในเมนู (ไม่ได้ขาย / ขายไม่ได้)
        for (int i = 0; i < SLOTS; i++) {
            ItemStack it = h.inv.getItem(i);
            if (it == null || it.getType() == Material.AIR) continue;
            h.inv.setItem(i, null);
            Map<Integer, ItemStack> rest = p.getInventory().addItem(it);
            for (ItemStack r : rest.values()) p.getWorld().dropItemNaturally(p.getLocation(), r);
        }
    }
}
