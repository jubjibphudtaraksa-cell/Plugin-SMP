package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * /shop — ร้านค้าแบบ DojoShop (ซื้ออย่างเดียว): เมนูหมวดหมู่ -> หน้าสินค้า (แบ่งหน้า) -> เลือกจำนวน -> ยืนยันซื้อ
 * ใช้เงินจาก EconomyManager ของ VortexCore
 * ไฟล์ตั้งค่าอยู่ใน plugins/VortexCore/shop/ (config.yml, categories.yml, shops/*.yml)
 * ไอเทมที่ใส่ {@code special: hammer} จะเป็นเครื่องมือ 3x3 (ดู {@link HammerModule})
 * ราคาซื้อของทุกไอเทมถูกใช้เป็นเพดานราคารับซื้อของ /sell ผ่าน {@link #buyPrice(Material)}
 */
public final class ShopModule implements CommandExecutor, TabCompleter, Listener {

    private static final String[] DEFAULT_SHOPS = {"blocks", "totem", "nether", "end", "food", "tools"};
    private static final int ITEMS_PER_PAGE = 45;
    private static final int SLOT_BACK_QTY = 18;
    private static final int CONFIRM_YES = 11;
    private static final int CONFIRM_NO = 15;

    /** ราคาเป็น cents */
    private record Entry(Material material, long price, String name, boolean hammer, String potion) {}

    private abstract static class Holder implements InventoryHolder {
        Inventory inv;

        @Override
        public @NotNull Inventory getInventory() { return inv; }
    }

    private static final class MainHolder extends Holder {
        final Map<Integer, String> slots = new HashMap<>();
    }

    private static final class ShopHolder extends Holder {
        String slug;
        int page;
        final Map<Integer, Entry> entries = new HashMap<>();
    }

    private static final class QtyHolder extends Holder {
        String slug;
        int page;
        Entry entry;
        int qty = 1;
        boolean confirm;
    }

    private final VortexCore plugin;
    private final EconomyManager eco;
    private final HammerModule hammer;

    private FileConfiguration config;
    private FileConfiguration categories;
    private final Map<String, FileConfiguration> shops = new LinkedHashMap<>();
    private final Map<Material, Long> buyPrices = new HashMap<>();

    public ShopModule(VortexCore plugin, EconomyManager eco, HammerModule hammer) {
        this.plugin = plugin;
        this.eco = eco;
        this.hammer = hammer;
        load();
    }

    // ------------------------------------------------------------ config

    private File dir() { return new File(plugin.getDataFolder(), "shop"); }

    private void saveDefaults() {
        if (!new File(dir(), "config.yml").exists()) plugin.saveResource("shop/config.yml", false);
        if (!new File(dir(), "categories.yml").exists()) plugin.saveResource("shop/categories.yml", false);
        for (String s : DEFAULT_SHOPS) {
            if (!new File(dir(), "shops/" + s + ".yml").exists()) plugin.saveResource("shop/shops/" + s + ".yml", false);
        }
    }

    public void load() {
        saveDefaults();
        config = YamlConfiguration.loadConfiguration(new File(dir(), "config.yml"));
        categories = YamlConfiguration.loadConfiguration(new File(dir(), "categories.yml"));
        shops.clear();
        buyPrices.clear();
        File[] files = new File(dir(), "shops").listFiles((d, n) -> n.endsWith(".yml"));
        if (files != null) {
            Arrays.sort(files);
            for (File f : files) {
                FileConfiguration cfg = YamlConfiguration.loadConfiguration(f);
                shops.put(f.getName().replace(".yml", "").toLowerCase(), cfg);
                for (Entry e : entries(cfg)) {
                    if (!e.hammer() && e.price() > 0) buyPrices.merge(e.material(), e.price(), Long::min);
                }
            }
        }
    }

    private List<Entry> entries(FileConfiguration cfg) {
        List<Entry> all = new ArrayList<>();
        for (Map<?, ?> m : cfg.getMapList("items")) {
            Material material = Material.matchMaterial(String.valueOf(m.get("material")));
            if (material == null || !material.isItem()) {
                plugin.getLogger().warning("shop: ไม่รู้จัก material: " + m.get("material"));
                continue;
            }
            double price = m.get("price") instanceof Number n ? n.doubleValue() : 0;
            String name = m.get("name") == null ? null : String.valueOf(m.get("name"));
            boolean hm = "hammer".equals(String.valueOf(m.get("special")));
            String potion = m.get("potion") == null ? null : String.valueOf(m.get("potion"));
            all.add(new Entry(material, Math.round(price * 100.0), name, hm, potion));
        }
        return all;
    }

    /** ราคาซื้อต่อชิ้นต่ำสุดจากร้าน (cents) — null ถ้าไม่มีขายในร้าน ใช้จำกัดราคารับซื้อของ /sell */
    public Long buyPrice(Material m) {
        return buyPrices.get(m);
    }

    // ------------------------------------------------------------ helpers

    private static Component c(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s == null ? "" : s)
                .decoration(TextDecoration.ITALIC, false);
    }

    private String msg(String key, String... pairs) {
        String m = config.getString("messages." + key, key);
        for (int i = 0; i + 1 < pairs.length; i += 2) m = m.replace(pairs[i], pairs[i + 1]);
        return config.getString("messages.prefix", "") + m;
    }

    private Material mat(String s, Material def) {
        Material m = s == null ? null : Material.matchMaterial(s);
        return m == null ? def : m;
    }

    private ItemStack pane(Material m, String name) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(c(name));
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack named(Material m, String name, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(c(name));
        if (lore != null && !lore.isEmpty()) meta.lore(lore.stream().map(ShopModule::c).toList());
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        it.setItemMeta(meta);
        return it;
    }

    private void fill(Inventory inv, int from, int to) {
        Material m = mat(config.getString("gui.filler", "GRAY_STAINED_GLASS_PANE"), Material.GRAY_STAINED_GLASS_PANE);
        ItemStack f = pane(m, " ");
        for (int i = from; i < to; i++) inv.setItem(i, f);
    }

    private void sound(Player p, String key) {
        try {
            Sound s = switch (key) {
                case "success" -> Sound.ENTITY_EXPERIENCE_ORB_PICKUP;
                case "fail" -> Sound.ENTITY_VILLAGER_NO;
                default -> Sound.UI_BUTTON_CLICK;
            };
            p.playSound(p.getLocation(), s, 1f, 1f);
        } catch (Throwable ignored) {
        }
    }

    private int hammerUses() { return Math.max(1, config.getInt("hammer.uses", 120)); }

    /** ไอเทมตัวอย่างที่แสดงในร้าน (ค้อน 3x3 จะมีชื่อ/lore ของค้อน) */
    private ItemStack baseItem(Entry e, int amount) {
        if (e.hammer()) return hammer.make(e.material(), e.name(), hammerUses());
        ItemStack it = stack(e, amount);
        if (e.name() != null) {
            ItemMeta meta = it.getItemMeta();
            meta.displayName(c(e.name()));
            it.setItemMeta(meta);
        }
        return it;
    }

    /** สร้างไอเทมตาม entry (รองรับ potion: เช่น ลูกธนู Slow Falling) */
    private ItemStack stack(Entry e, int amount) {
        ItemStack it = new ItemStack(e.material(), amount);
        if (e.potion() != null && it.getItemMeta() instanceof PotionMeta pm) {
            PotionType type = null;
            try {
                type = PotionType.valueOf(e.potion().toUpperCase());
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("shop: ไม่รู้จัก potion: " + e.potion());
            }
            if (type != null) {
                pm.setBasePotionType(type);
                it.setItemMeta(pm);
            }
        }
        return it;
    }

    private String itemName(Entry e) {
        if (e.name() != null) return e.name();
        if (e.potion() != null) return e.potion().toLowerCase().replace('_', ' ') + " " + e.material().name().toLowerCase().replace('_', ' ');
        return e.material().name().toLowerCase().replace('_', ' ');
    }

    // ------------------------------------------------------------------- main

    private void openMain(Player p) {
        MainHolder h = new MainHolder();
        int size = Math.max(9, Math.min(54, categories.getInt("size", 27)));
        h.inv = Bukkit.createInventory(h, size, c(categories.getString("title", "&8Shop")));
        if (categories.getBoolean("fill-empty", true)) fill(h.inv, 0, size);

        ConfigurationSection cats = categories.getConfigurationSection("categories");
        if (cats != null) {
            for (String key : cats.getKeys(false)) {
                ConfigurationSection s = cats.getConfigurationSection(key);
                if (s == null) continue;
                int slot = s.getInt("slot", 0);
                if (slot < 0 || slot >= size) continue;
                h.inv.setItem(slot, named(mat(s.getString("material"), Material.CHEST),
                        s.getString("name", "&f" + key), s.getStringList("lore")));
                h.slots.put(slot, s.getString("shop", key).toLowerCase());
            }
        }
        p.openInventory(h.inv);
    }

    // ------------------------------------------------------------------- shop

    private void openShop(Player p, String slug, int page) {
        FileConfiguration cfg = shops.get(slug);
        if (cfg == null) {
            p.sendMessage(c(msg("unknown-shop")));
            return;
        }
        List<Entry> all = entries(cfg);
        int pages = Math.max(1, (int) Math.ceil(all.size() / (double) ITEMS_PER_PAGE));
        page = Math.max(0, Math.min(page, pages - 1));

        ShopHolder h = new ShopHolder();
        h.slug = slug;
        h.page = page;
        h.inv = Bukkit.createInventory(h, 54, c(cfg.getString("title", "&8" + slug)));

        int start = page * ITEMS_PER_PAGE;
        for (int i = 0; i < ITEMS_PER_PAGE && start + i < all.size(); i++) {
            Entry e = all.get(start + i);
            h.inv.setItem(i, shopItem(e));
            h.entries.put(i, e);
        }
        fill(h.inv, 45, 54);
        if (page > 0) h.inv.setItem(48, pane(Material.ARROW, "&aหน้าก่อนหน้า"));
        h.inv.setItem(49, pane(Material.BARRIER, "&cกลับ"));
        if (page < pages - 1) h.inv.setItem(50, pane(Material.ARROW, "&aหน้าถัดไป"));
        p.openInventory(h.inv);
    }

    private ItemStack shopItem(Entry e) {
        ItemStack it = baseItem(e, 1);
        ItemMeta meta = it.getItemMeta();
        List<Component> lore = new ArrayList<>(meta.hasLore() && meta.lore() != null ? meta.lore() : List.of());
        lore.add(Component.empty());
        lore.add(c("&7ราคา: &a" + eco.format(e.price())));
        lore.add(Component.empty());
        lore.add(c(e.hammer() ? "&eคลิกเพื่อซื้อ" : "&eคลิกเพื่อเลือกจำนวน"));
        meta.lore(lore);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        it.setItemMeta(meta);
        return it;
    }

    // --------------------------------------------------------------- quantity

    private void openQty(Player p, String slug, int page, Entry entry) {
        QtyHolder h = new QtyHolder();
        h.slug = slug;
        h.page = page;
        h.entry = entry;
        h.confirm = config.getBoolean("gui.confirm-only", true);
        if (h.confirm) {
            h.inv = Bukkit.createInventory(h, 27, c(config.getString("gui.confirm-title", "&8ยืนยันการซื้อ")));
            renderConfirm(h);
        } else {
            h.inv = Bukkit.createInventory(h, 27, c(config.getString("gui.quantity-title", "&8เลือกจำนวน")));
            renderQty(h);
        }
        p.openInventory(h.inv);
    }

    private long total(Entry e, int qty) {
        return e.price() * qty;
    }

    /** หน้ายืนยัน: ไอเทมตรงกลาง ปุ่มเขียว = ซื้อ 1 ชิ้น, ปุ่มแดง = ยกเลิก */
    private void renderConfirm(QtyHolder h) {
        Inventory inv = h.inv;
        fill(inv, 0, 27);
        ItemStack show = baseItem(h.entry, 1);
        ItemMeta meta = show.getItemMeta();
        meta.lore(List.of(
                c(""),
                c("&7ราคา: &a" + eco.format(h.entry.price()))));
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        show.setItemMeta(meta);
        inv.setItem(13, show);
        inv.setItem(CONFIRM_YES, named(Material.LIME_CONCRETE, "&a&lยืนยัน",
                List.of("", "&7ซื้อ 1 ชิ้น", "&7ราคา: &a" + eco.format(h.entry.price()))));
        inv.setItem(CONFIRM_NO, named(Material.RED_CONCRETE, "&c&lยกเลิก", List.of("", "&7กลับไปหน้าร้าน")));
    }

    private void renderQty(QtyHolder h) {
        Inventory inv = h.inv;
        fill(inv, 0, 27);
        long total = total(h.entry, h.qty);

        ItemStack show = baseItem(h.entry, Math.max(1, Math.min(h.qty, h.entry.material().getMaxStackSize())));
        ItemMeta meta = show.getItemMeta();
        meta.lore(List.of(
                c(""),
                c("&7จำนวน: &f" + h.qty),
                c("&7ราคาต่อชิ้น: &a" + eco.format(h.entry.price())),
                c("&7ราคารวม: &a" + eco.format(total))));
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        show.setItemMeta(meta);
        inv.setItem(13, show);

        inv.setItem(10, pane(Material.RED_STAINED_GLASS_PANE, "&c-10"));
        inv.setItem(11, pane(Material.RED_STAINED_GLASS_PANE, "&c-1"));
        inv.setItem(15, pane(Material.LIME_STAINED_GLASS_PANE, "&a+1"));
        inv.setItem(16, pane(Material.LIME_STAINED_GLASS_PANE, "&a+10"));
        inv.setItem(12, pane(Material.RED_STAINED_GLASS_PANE, "&cReset (1)"));
        inv.setItem(14, pane(Material.LIME_STAINED_GLASS_PANE, "&aตั้งเป็น 64"));
        inv.setItem(22, named(Material.EMERALD_BLOCK, "&a&lยืนยันการซื้อ",
                List.of("", "&7จำนวน: &f" + h.qty, "&7ราคารวม: &a" + eco.format(total))));
        inv.setItem(SLOT_BACK_QTY, pane(Material.BARRIER, "&cกลับ"));
    }

    // ------------------------------------------------------------------ buy

    private int freeSpace(Player p, Material m) {
        int free = 0;
        for (ItemStack s : p.getInventory().getStorageContents()) {
            if (s == null || s.getType().isAir()) free += m.getMaxStackSize();
            else if (s.getType() == m && !s.hasItemMeta()) free += Math.max(0, m.getMaxStackSize() - s.getAmount());
        }
        return free;
    }

    private void buy(Player p, Entry e, int qty) {
        if (e.price() <= 0) {
            p.sendMessage(c(msg("unknown-shop")));
            return;
        }
        if (e.hammer()) qty = 1;
        else if (freeSpace(p, e.material()) < qty) {
            p.sendMessage(c(msg("no-space")));
            sound(p, "fail");
            return;
        }
        long total;
        try {
            total = Math.multiplyExact(e.price(), (long) qty);
        } catch (ArithmeticException ex) {
            p.sendMessage(c(msg("no-money", "%price%", "∞")));
            sound(p, "fail");
            return;
        }
        if (!eco.has(p.getUniqueId(), total)
                || eco.withdraw(p.getUniqueId(), total) != EconomyManager.Tx.SUCCESS) {
            p.sendMessage(c(msg("no-money", "%price%", eco.format(total))));
            sound(p, "fail");
            return;
        }
        if (e.hammer()) {
            p.getInventory().addItem(hammer.make(e.material(), e.name(), hammerUses()))
                    .values().forEach(l -> p.getWorld().dropItemNaturally(p.getLocation(), l));
        } else {
            int left = qty;
            int stack = e.material().getMaxStackSize();
            while (left > 0) {
                int n = Math.min(stack, left);
                p.getInventory().addItem(stack(e, n))
                        .values().forEach(l -> p.getWorld().dropItemNaturally(p.getLocation(), l));
                left -= n;
            }
        }
        p.sendMessage(c(msg("bought", "%amount%", String.valueOf(qty), "%item%", itemName(e), "%price%", eco.format(total))));
        sound(p, "success");
    }

    // ---------------------------------------------------------------- events

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder holder)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() != top) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        int slot = e.getSlot();

        if (holder instanceof MainHolder mh) {
            String slug = mh.slots.get(slot);
            if (slug != null) {
                sound(p, "click");
                openShop(p, slug, 0);
            }
        } else if (holder instanceof ShopHolder sh) {
            Entry en = sh.entries.get(slot);
            if (en != null) {
                sound(p, "click");
                if (en.hammer()) buy(p, en, 1);
                else openQty(p, sh.slug, sh.page, en);
            } else if (slot == 49) {
                sound(p, "click");
                openMain(p);
            } else if (slot == 48 && sh.page > 0) {
                sound(p, "click");
                openShop(p, sh.slug, sh.page - 1);
            } else if (slot == 50 && top.getItem(50) != null && top.getItem(50).getType() == Material.ARROW) {
                sound(p, "click");
                openShop(p, sh.slug, sh.page + 1);
            }
        } else if (holder instanceof QtyHolder qh && qh.confirm) {
            if (slot == CONFIRM_YES) {
                buy(p, qh.entry, 1);
                p.closeInventory();
            } else if (slot == CONFIRM_NO) {
                sound(p, "click");
                openShop(p, qh.slug, qh.page);
            }
        } else if (holder instanceof QtyHolder qh) {
            int max = Math.max(1, config.getInt("max-quantity", 2304));
            int before = qh.qty;
            switch (slot) {
                case 10 -> qh.qty -= 10;
                case 11 -> qh.qty -= 1;
                case 12 -> qh.qty = 1;
                case 14 -> qh.qty = 64;
                case 15 -> qh.qty += 1;
                case 16 -> qh.qty += 10;
                case 22 -> {
                    buy(p, qh.entry, qh.qty);
                    return;
                }
                case SLOT_BACK_QTY -> {
                    sound(p, "click");
                    openShop(p, qh.slug, qh.page);
                    return;
                }
                default -> {
                    return;
                }
            }
            qh.qty = Math.max(1, Math.min(max, qh.qty));
            if (qh.qty != before) sound(p, "click");
            renderQty(qh);
        }
    }

    // ------------------------------------------------------------ command

    @Override
    public boolean onCommand(@NotNull CommandSender s, @NotNull Command cmd, @NotNull String label, @NotNull String[] a) {
        if (a.length >= 1 && a[0].equalsIgnoreCase("reload")) {
            if (!s.hasPermission("vortexcore.eco.admin")) {
                s.sendMessage(c(msg("no-permission")));
                return true;
            }
            plugin.reloadConfig();
            load();
            plugin.reloadSellPrices();
            s.sendMessage(c(msg("reloaded")));
            return true;
        }
        if (a.length >= 3 && a[0].equalsIgnoreCase("givehammer")) {
            if (!s.hasPermission("vortexcore.eco.admin")) {
                s.sendMessage(c(msg("no-permission")));
                return true;
            }
            Player t = Bukkit.getPlayerExact(a[1]);
            if (t == null) { s.sendMessage("player not found"); return true; }
            Material want = Material.matchMaterial("NETHERITE_" + a[2].toUpperCase());
            for (FileConfiguration cfg : shops.values()) {
                for (Entry en : entries(cfg)) {
                    if (en.hammer() && en.material() == want) {
                        t.getInventory().addItem(hammer.make(en.material(), en.name(), hammerUses()));
                        s.sendMessage("gave " + en.material().name() + " to " + t.getName());
                        return true;
                    }
                }
            }
            s.sendMessage("usage: /shop givehammer <player> <pickaxe|shovel|axe|hoe>");
            return true;
        }
        if (!(s instanceof Player p)) {
            s.sendMessage("Players only.");
            return true;
        }
        if (!p.hasPermission("shop.use")) {
            p.sendMessage(c(msg("no-permission")));
            return true;
        }
        if (!Smp.is(p)) {
            Smp.notHere(p);
            return true;
        }
        if (a.length > 0 && shops.containsKey(a[0].toLowerCase())) openShop(p, a[0].toLowerCase(), 0);
        else openMain(p);
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender s, @NotNull Command cmd, @NotNull String l, @NotNull String[] a) {
        if (a.length == 1) {
            List<String> out = new ArrayList<>(shops.keySet());
            if (s.hasPermission("vortexcore.eco.admin")) {
                out.add("reload");
                out.add("givehammer");
            }
            out.removeIf(x -> !x.startsWith(a[0].toLowerCase()));
            return out;
        }
        if (a.length == 3 && a[0].equalsIgnoreCase("givehammer") && s.hasPermission("vortexcore.eco.admin")) {
            return List.of("pickaxe", "shovel", "axe", "hoe");
        }
        return List.of();
    }
}
