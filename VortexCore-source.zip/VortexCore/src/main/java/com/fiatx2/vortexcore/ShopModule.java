package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.inventory.PrepareGrindstoneEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.RayTraceResult;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * /shop — ร้านค้า (พอร์ตจาก ShopPlugin): เมนูหลัก -> หมวด -> ซ้าย = เลือกจำนวนแล้วซื้อ, ขวา = ขาย (Shift = ทั้งหมด)
 * มีเครื่องมือเนเธอร์ไรต์ 3x3 (special: hammer) ซื้อได้อย่างเดียว คราฟ/ซ่อม/ใส่เอนชานท์ไม่ได้
 * ใช้เงินจาก EconomyManager ของ VortexCore และให้ราคารับซื้อกับ /sell ผ่าน {@link #sellPrice(Material)}
 */
public final class ShopModule implements CommandExecutor, TabCompleter, Listener {

    /** ราคาเป็น cents (<= 0 = ไม่มี) */
    private record Entry(Material mat, String name, long buy, long sell, boolean hammer) {}

    private record Category(String name, Material icon, int slot, List<Entry> items) {}

    private enum Kind { MAIN, CAT, QTY }

    private static final class Menu implements InventoryHolder {
        final Kind kind;
        final String cat;
        final Map<Integer, String> main = new HashMap<>();
        final Map<Integer, Entry> items = new HashMap<>();
        Entry entry;
        int qty = 1;
        Inventory inv;

        Menu(Kind kind, String cat) {
            this.kind = kind;
            this.cat = cat;
        }

        @Override
        public @NotNull Inventory getInventory() { return inv; }
    }

    // ปุ่มปรับจำนวนในเมนูเลือกจำนวน: slot -> เพิ่ม/ลด
    private static final Map<Integer, Integer> QTY_BTN = Map.of(
            0, -1000, 1, -256, 9, -64, 10, -16, 11, -1,
            15, 1, 16, 16, 17, 64, 7, 256, 8, 1000);

    private static final List<String> DEFAULT_BLOCKED = List.of(
            "BEDROCK", "BARRIER", "LIGHT", "STRUCTURE_BLOCK", "STRUCTURE_VOID", "JIGSAW", "DEBUG_STICK",
            "KNOWLEDGE_BOOK", "SPAWNER", "TRIAL_SPAWNER", "VAULT", "END_PORTAL_FRAME", "REINFORCED_DEEPSLATE",
            "COMMAND_BLOCK", "CHAIN_COMMAND_BLOCK", "REPEATING_COMMAND_BLOCK", "PETRIFIED_OAK_SLAB",
            "NETHER_STAR", "ELYTRA", "DRAGON_EGG", "ENCHANTED_GOLDEN_APPLE", "BEACON", "TRIDENT", "MACE",
            "HEAVY_CORE", "CONDUIT", "HEART_OF_THE_SEA", "TOTEM_OF_UNDYING", "OMINOUS_TRIAL_KEY", "TRIAL_KEY");

    private final VortexCore plugin;
    private final EconomyManager eco;
    private final NamespacedKey usesKey;
    private final Set<UUID> breaking = new HashSet<>();
    private final Map<String, Category> cats = new LinkedHashMap<>();

    /** ราคารับซื้อของ /sell (cents) */
    private final Map<Material, Long> sellPrices = new HashMap<>();
    /** ราคาซื้อจากร้าน (cents) ใช้จำกัดราคารับซื้อไม่ให้สูงกว่าราคาขาย (กันปั๊มเงิน) */
    private final Map<Material, Long> buyPrices = new HashMap<>();
    private final Set<String> blockedSell = new HashSet<>();
    /** ราคารับซื้อสำหรับไอเทมที่ไม่ได้ระบุ (cents) — 0 = ปิด */
    private long defaultSell = 0;

    private String title = "&6&lร้านค้า";
    private int hammerUses = 120;
    private int maxQty = 100000;

    public ShopModule(VortexCore plugin, EconomyManager eco) {
        this.plugin = plugin;
        this.eco = eco;
        this.usesKey = new NamespacedKey(plugin, "hammer_uses");
        load();
    }

    private static long cents(double v) {
        return Math.round(v * 100.0);
    }

    // ------------------------------------------------------------ config

    private void load() {
        cats.clear();
        sellPrices.clear();
        buyPrices.clear();
        blockedSell.clear();
        defaultSell = cents(plugin.getConfig().getDouble("sell.default-price", 0.25));
        blockedSell.addAll(DEFAULT_BLOCKED);
        for (String b : plugin.getConfig().getStringList("sell.blocked")) blockedSell.add(b.toUpperCase());

        File f = new File(plugin.getDataFolder(), "shop.yml");
        if (!f.exists()) plugin.saveResource("shop.yml", false);
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(f);
        title = cfg.getString("title", "&6&lร้านค้า");
        hammerUses = cfg.getInt("hammer.uses", 120);
        maxQty = Math.max(1, cfg.getInt("max-quantity", 100000));

        ConfigurationSection cs = cfg.getConfigurationSection("categories");
        if (cs != null) {
            for (String id : cs.getKeys(false)) {
                ConfigurationSection sec = cs.getConfigurationSection(id);
                if (sec == null) continue;
                List<Entry> list = new ArrayList<>();
                for (Map<?, ?> m : sec.getMapList("items")) {
                    boolean hammer = "hammer".equals(String.valueOf(m.get("special")));
                    Material mat = Material.matchMaterial(String.valueOf(m.get("material")));
                    if (mat == null || !mat.isItem()) {
                        plugin.getLogger().warning("shop.yml: ไม่รู้จัก material: " + m.get("material"));
                        continue;
                    }
                    long buy = m.get("buy") instanceof Number n ? cents(n.doubleValue()) : -1;
                    long sell = m.get("sell") instanceof Number n ? cents(n.doubleValue()) : -1;
                    String name = m.get("name") != null ? String.valueOf(m.get("name")) : "&b&l3x3 " + mat.name();
                    list.add(new Entry(mat, name, buy, sell, hammer));
                    if (!hammer) {
                        if (sell > 0) sellPrices.putIfAbsent(mat, sell);
                        if (buy > 0) buyPrices.putIfAbsent(mat, buy);
                    }
                }
                Material icon = Material.matchMaterial(sec.getString("icon", "CHEST"));
                cats.put(id, new Category(sec.getString("name", id), icon == null ? Material.CHEST : icon,
                        sec.getInt("slot", 10), list));
            }
        }

        // ราคารับซื้อเฉพาะ /sell (ไม่แสดงใน /shop)
        ConfigurationSection sp = cfg.getConfigurationSection("sell-prices");
        if (sp != null) {
            for (String mk : sp.getKeys(false)) {
                Material m = Material.matchMaterial(mk);
                long v = cents(sp.getDouble(mk, 0));
                if (m == null || !m.isItem() || v <= 0) {
                    plugin.getLogger().warning("shop.yml: ข้าม sell-prices '" + mk + "'");
                    continue;
                }
                sellPrices.putIfAbsent(m, v);
            }
        }
        // ราคารับซื้อต้องไม่เกินราคาซื้อจากร้าน
        for (Map.Entry<Material, Long> e : buyPrices.entrySet()) {
            Long sv = sellPrices.get(e.getKey());
            if (sv != null && sv > e.getValue()) sellPrices.put(e.getKey(), e.getValue());
        }
    }

    /** ราคารับซื้อต่อชิ้น (cents) สำหรับ /sell — 0 ถ้าไม่รับซื้อ */
    public long sellPrice(Material m) {
        Long v = sellPrices.get(m);
        if (v != null) return v;
        if (defaultSell <= 0 || !m.isItem() || m.isAir() || m.name().startsWith("LEGACY_")) return 0;
        String n = m.name();
        if (blockedSell.contains(n) || n.endsWith("_SPAWN_EGG") || n.startsWith("NETHERITE_")) return 0;
        long cap = buyPrices.getOrDefault(m, Long.MAX_VALUE);
        return Math.min(defaultSell, cap);
    }

    // ------------------------------------------------------------ helpers

    private Component c(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    private void msg(Player p, String s) {
        p.sendMessage(c("&6[Shop] &f" + s));
    }

    private ItemStack named(Material mat, String name, String... lore) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.displayName(c(name));
        if (lore.length > 0) m.lore(Arrays.stream(lore).map(this::c).toList());
        it.setItemMeta(m);
        return it;
    }

    private ItemStack makeHammer(Entry en, int uses) {
        ItemStack it = new ItemStack(en.mat());
        ItemMeta m = it.getItemMeta();
        m.displayName(c(en.name()));
        m.setUnbreakable(true);
        m.getPersistentDataContainer().set(usesKey, PersistentDataType.INTEGER, uses);
        it.setItemMeta(m);
        updateLore(it, uses);
        return it;
    }

    private void updateLore(ItemStack it, int uses) {
        ItemMeta m = it.getItemMeta();
        m.getPersistentDataContainer().set(usesKey, PersistentDataType.INTEGER, uses);
        m.lore(List.of(
                c("&7ขุดทีละ &f3x3 &7บล็อก &8(เนเธอร์ไรต์)"),
                c("&7ใช้ได้อีก: &e" + uses + " &7ครั้ง"),
                c("&8นั่งยอง (Shift) = ขุดบล็อกเดียว ไม่เสียจำนวนครั้ง"),
                c("&cคราฟไม่ได้ ซื้อได้อย่างเดียว")));
        it.setItemMeta(m);
    }

    private Integer getUses(ItemStack it) {
        if (it == null || !it.getType().name().startsWith("NETHERITE_") || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(usesKey, PersistentDataType.INTEGER);
    }

    // ------------------------------------------------------------ GUI

    private void openMain(Player p) {
        Menu m = new Menu(Kind.MAIN, null);
        m.inv = Bukkit.createInventory(m, 27, c(title));
        for (Map.Entry<String, Category> e : cats.entrySet()) {
            Category cat = e.getValue();
            if (cat.slot() < 0 || cat.slot() >= 27) continue;
            m.inv.setItem(cat.slot(), named(cat.icon(), cat.name(), "&7คลิกเพื่อเปิด"));
            m.main.put(cat.slot(), e.getKey());
        }
        p.openInventory(m.inv);
    }

    private void openCat(Player p, String id) {
        Category cat = cats.get(id);
        if (cat == null) return;
        Menu m = new Menu(Kind.CAT, id);
        m.inv = Bukkit.createInventory(m, 54, c(cat.name()));
        for (int i = 0; i < cat.items().size() && i < 45; i++) {
            Entry en = cat.items().get(i);
            ItemStack it = en.hammer() ? makeHammer(en, hammerUses) : new ItemStack(en.mat());
            ItemMeta meta = it.getItemMeta();
            List<Component> lore = new ArrayList<>(meta.hasLore() ? meta.lore() : List.of());
            lore.add(Component.empty());
            lore.add(c(en.buy() > 0
                    ? "&aซื้อ: &f" + eco.format(en.buy()) + " &7(คลิกซ้าย" + (en.hammer() ? ")" : " = เลือกจำนวน)")
                    : "&cซื้อไม่ได้"));
            if (!en.hammer())
                lore.add(c(en.sell() > 0 ? "&eขาย: &f" + eco.format(en.sell()) + " &7(คลิกขวา, Shift = ทั้งหมด)" : "&cขายไม่ได้"));
            meta.lore(lore);
            it.setItemMeta(meta);
            m.inv.setItem(i, it);
            m.items.put(i, en);
        }
        m.inv.setItem(49, named(Material.BARRIER, "&cกลับ"));
        p.openInventory(m.inv);
    }

    private void openQty(Player p, String catId, Entry en) {
        Menu m = new Menu(Kind.QTY, catId);
        m.entry = en;
        m.qty = 1;
        m.inv = Bukkit.createInventory(m, 27, c("&8เลือกจำนวนที่ซื้อ"));
        renderQty(m);
        p.openInventory(m.inv);
    }

    private long total(Entry en, int qty) {
        return en.buy() * qty;
    }

    private void renderQty(Menu m) {
        Entry en = m.entry;
        Inventory inv = m.inv;
        inv.clear();
        for (Map.Entry<Integer, Integer> b : QTY_BTN.entrySet()) {
            int d = b.getValue();
            inv.setItem(b.getKey(), named(d < 0 ? Material.RED_STAINED_GLASS_PANE : Material.LIME_STAINED_GLASS_PANE,
                    (d < 0 ? "&c" : "&a") + (d < 0 ? "" : "+") + d));
        }
        ItemStack show = new ItemStack(en.mat(), Math.max(1, Math.min(m.qty, en.mat().getMaxStackSize())));
        ItemMeta sm = show.getItemMeta();
        sm.lore(List.of(
                c("&7จำนวน: &f" + m.qty),
                c("&7ราคาต่อชิ้น: &f" + eco.format(en.buy())),
                c("&aรวม: &f" + eco.format(total(en, m.qty)))));
        show.setItemMeta(sm);
        inv.setItem(13, show);
        inv.setItem(20, named(Material.BARRIER, "&cยกเลิก"));
        inv.setItem(22, named(Material.HOPPER, "&eเต็มสแต็ก (" + en.mat().getMaxStackSize() + ")"));
        inv.setItem(24, named(Material.EMERALD_BLOCK, "&a&lยืนยันซื้อ",
                "&7จำนวน: &f" + m.qty, "&7รวม: &f" + eco.format(total(en, m.qty))));
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Menu m)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;
        Player p = (Player) e.getWhoClicked();
        int s = e.getSlot();

        switch (m.kind) {
            case MAIN -> {
                String id = m.main.get(s);
                if (id != null) openCat(p, id);
            }
            case CAT -> {
                if (s == 49) { openMain(p); return; }
                Entry en = m.items.get(s);
                if (en == null) return;
                if (e.isLeftClick()) {
                    if (en.buy() <= 0) { msg(p, "&cไอเทมนี้ซื้อไม่ได้"); return; }
                    if (en.hammer()) buy(p, en, 1);
                    else openQty(p, m.cat, en);
                } else if (e.isRightClick()) {
                    sell(p, en, e.isShiftClick());
                }
            }
            case QTY -> {
                Integer d = QTY_BTN.get(s);
                if (d != null) {
                    m.qty = Math.max(1, Math.min(maxQty, m.qty + d));
                    renderQty(m);
                } else if (s == 22) {
                    m.qty = Math.min(maxQty, m.entry.mat().getMaxStackSize());
                    renderQty(m);
                } else if (s == 20) {
                    openCat(p, m.cat);
                } else if (s == 24) {
                    buy(p, m.entry, m.qty);
                }
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Menu) e.setCancelled(true);
    }

    // ------------------------------------------------------------ buy / sell

    private void buy(Player p, Entry en, int amt) {
        if (en.buy() <= 0) { msg(p, "&cไอเทมนี้ซื้อไม่ได้"); return; }
        if (en.hammer()) {
            amt = 1;
        } else {
            int space = freeSpace(p, en.mat());
            if (space <= 0) { msg(p, "&cช่องเก็บของเต็ม"); return; }
            if (amt > space) {
                amt = space;
                msg(p, "&eช่องเก็บของไม่พอ ซื้อได้แค่ &f" + amt + " &eชิ้น");
            }
        }
        long cost;
        try {
            cost = Math.multiplyExact(en.buy(), (long) amt);
        } catch (ArithmeticException ex) {
            msg(p, "&cราคารวมสูงเกินไป");
            return;
        }
        if (!eco.has(p.getUniqueId(), cost)) { msg(p, "&cเงินไม่พอ ต้องใช้ " + eco.format(cost)); return; }
        if (eco.withdraw(p.getUniqueId(), cost) != EconomyManager.Tx.SUCCESS) { msg(p, "&cซื้อไม่สำเร็จ"); return; }
        ItemStack it = en.hammer() ? makeHammer(en, hammerUses) : new ItemStack(en.mat(), amt);
        p.getInventory().addItem(it).values().forEach(l -> p.getWorld().dropItemNaturally(p.getLocation(), l));
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1f);
        msg(p, "&aซื้อ &f" + amt + "x " + (en.hammer() ? "เครื่องมือ 3x3 (" + en.mat().name() + ")" : en.mat().name())
                + " &aราคา " + eco.format(cost));
    }

    private int freeSpace(Player p, Material mat) {
        int max = mat.getMaxStackSize(), space = 0;
        for (ItemStack s : p.getInventory().getStorageContents()) {
            if (s == null || s.getType().isAir()) space += max;
            else if (s.getType() == mat && !s.hasItemMeta()) space += Math.max(0, max - s.getAmount());
        }
        return space;
    }

    private void sell(Player p, Entry en, boolean all) {
        if (en.hammer() || en.sell() <= 0) { msg(p, "&cไอเทมนี้ขายไม่ได้"); return; }
        int want = all ? Integer.MAX_VALUE : 1, sold = 0;
        ItemStack[] contents = p.getInventory().getStorageContents();
        for (int i = 0; i < contents.length && sold < want; i++) {
            ItemStack s = contents[i];
            if (s == null || s.getType() != en.mat() || s.hasItemMeta()) continue;
            int take = Math.min(s.getAmount(), want - sold);
            sold += take;
            if (take >= s.getAmount()) contents[i] = null;
            else {
                ItemStack rest = s.clone();
                rest.setAmount(s.getAmount() - take);
                contents[i] = rest;
            }
        }
        if (sold == 0) { msg(p, "&cคุณไม่มีไอเทมนี้"); return; }
        long money = en.sell() * sold;
        if (eco.deposit(p.getUniqueId(), money) != EconomyManager.Tx.SUCCESS) {
            msg(p, "&cขายไม่สำเร็จ (เงินเต็มเพดาน)");
            return;
        }
        p.getInventory().setStorageContents(contents);
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.4f);
        msg(p, "&eขาย &f" + sold + "x " + en.mat().name() + " &eได้ " + eco.format(money));
    }

    // ------------------------------------------------------------ 3x3 tools

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (breaking.contains(p.getUniqueId())) return;
        ItemStack tool = p.getInventory().getItemInMainHand();
        Integer uses = getUses(tool);
        if (uses == null) return;
        if (p.isSneaking()) return;

        Block center = e.getBlock();
        RayTraceResult r = p.rayTraceBlocks(6);
        BlockFace face = (r != null && center.equals(r.getHitBlock()) && r.getHitBlockFace() != null)
                ? r.getHitBlockFace() : p.getFacing().getOppositeFace();

        breaking.add(p.getUniqueId());
        try {
            for (int a = -1; a <= 1; a++) {
                for (int b = -1; b <= 1; b++) {
                    if (a == 0 && b == 0) continue;
                    Block t = face.getModX() != 0 ? center.getRelative(0, a, b)
                            : face.getModY() != 0 ? center.getRelative(a, 0, b)
                            : center.getRelative(a, b, 0);
                    Material type = t.getType();
                    if (type.isAir() || t.isLiquid() || type.getHardness() < 0) continue;
                    if (t.getDestroySpeed(tool) <= 1f) continue;
                    BlockBreakEvent be = new BlockBreakEvent(t, p);
                    if (!be.callEvent()) continue;
                    if (be.isDropItems()) t.breakNaturally(tool);
                    else t.setType(Material.AIR);
                }
            }
        } finally {
            breaking.remove(p.getUniqueId());
        }

        int left = uses - 1;
        if (left <= 0) {
            p.getInventory().setItemInMainHand(null);
            p.playSound(p.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 1f);
            msg(p, "&cเครื่องมือ 3x3 ของคุณหมดอายุการใช้งานแล้ว");
        } else {
            updateLore(tool, left);
            p.getInventory().setItemInMainHand(tool);
            if (left <= 10) p.sendActionBar(c("&cเหลืออีก " + left + " ครั้ง"));
        }
    }

    @EventHandler
    public void onAnvil(PrepareAnvilEvent e) {
        for (ItemStack i : e.getInventory().getContents())
            if (getUses(i) != null) { e.setResult(null); return; }
    }

    @EventHandler
    public void onCraft(PrepareItemCraftEvent e) {
        for (ItemStack i : e.getInventory().getMatrix())
            if (getUses(i) != null) { e.getInventory().setResult(null); return; }
    }

    @EventHandler
    public void onGrind(PrepareGrindstoneEvent e) {
        for (ItemStack i : e.getInventory().getContents())
            if (getUses(i) != null) { e.setResult(null); return; }
    }

    // ------------------------------------------------------------ command

    @Override
    public boolean onCommand(@NotNull CommandSender s, @NotNull Command cmd, @NotNull String label, @NotNull String[] a) {
        if (a.length >= 1 && a[0].equalsIgnoreCase("reload")) {
            if (!s.hasPermission("vortexcore.eco.admin")) { s.sendMessage("no permission"); return true; }
            plugin.reloadConfig();
            load();
            s.sendMessage("Shop reloaded");
            return true;
        }
        if (a.length >= 3 && a[0].equalsIgnoreCase("givehammer")) {
            if (!s.hasPermission("vortexcore.eco.admin")) { s.sendMessage("no permission"); return true; }
            Player t = Bukkit.getPlayerExact(a[1]);
            if (t == null) { s.sendMessage("player not found"); return true; }
            Material want = Material.matchMaterial("NETHERITE_" + a[2].toUpperCase());
            for (Category cat : cats.values())
                for (Entry en : cat.items())
                    if (en.hammer() && en.mat() == want) {
                        t.getInventory().addItem(makeHammer(en, hammerUses));
                        s.sendMessage("gave " + en.mat().name() + " to " + t.getName());
                        return true;
                    }
            s.sendMessage("usage: /shop givehammer <player> <pickaxe|shovel|axe|hoe>");
            return true;
        }
        if (!(s instanceof Player p)) return true;
        if (!Smp.is(p)) {
            Smp.notHere(p);
            return true;
        }
        openMain(p);
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender s, @NotNull Command cmd, @NotNull String l, @NotNull String[] a) {
        if (a.length == 1 && s.hasPermission("vortexcore.eco.admin")) return List.of("reload", "givehammer");
        if (a.length == 3 && a[0].equalsIgnoreCase("givehammer")) return List.of("pickaxe", "shovel", "axe", "hoe");
        return List.of();
    }
}
