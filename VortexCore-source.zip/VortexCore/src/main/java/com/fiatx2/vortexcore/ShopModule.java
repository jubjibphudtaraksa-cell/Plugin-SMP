package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * /shop — ร้านค้าแบบเมนูกล่องเรียบๆ (สไตล์ Dojo)
 * เมนูหลัก -> หมวด -> คลิกไอเทม (ซ้าย = ซื้อ, ขวา = ขาย) -> หน้าเลือกจำนวน -> ยืนยัน
 */
public final class ShopModule implements CommandExecutor, TabCompleter, Listener {

    private record Entry(Material mat, long buy, long sell) {}

    private record Category(String key, String name, Material icon, int slot, List<Entry> items) {}

    private enum Type { MAIN, CAT, QTY }

    private static final class Holder implements InventoryHolder {
        final Type type;
        final Category cat;
        final int page;
        // CAT
        final Map<Integer, Entry> entries = new HashMap<>();
        int back = -1, prev = -1, next = -1;
        // MAIN
        final Map<Integer, Category> cats = new HashMap<>();
        // QTY
        Entry entry;
        boolean buying;
        int amount = 1;
        Inventory inv;

        Holder(Type type, Category cat, int page) {
            this.type = type;
            this.cat = cat;
            this.page = page;
        }

        @Override
        public @NotNull Inventory getInventory() { return inv; }
    }

    private static final int[] DEFAULT_SLOTS = {11, 12, 13, 14, 15, 3, 5, 10, 16, 19, 20, 21, 23, 24};
    private static final int CLOSE_SLOT = 22;

    private final VortexCore plugin;
    private final EconomyManager eco;
    private final List<Category> categories = new ArrayList<>();

    public ShopModule(VortexCore plugin, EconomyManager eco) {
        this.plugin = plugin;
        this.eco = eco;
        load();
    }

    // ------------------------------------------------------------ config

    private void load() {
        categories.clear();
        File f = new File(plugin.getDataFolder(), "shop.yml");
        if (!f.exists()) plugin.saveResource("shop.yml", false);
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        ConfigurationSection cs = y.getConfigurationSection("categories");
        if (cs == null) return;
        for (String key : cs.getKeys(false)) {
            ConfigurationSection c = cs.getConfigurationSection(key);
            if (c == null) continue;
            if (categories.size() >= DEFAULT_SLOTS.length) {
                plugin.getLogger().warning("shop.yml: รองรับสูงสุด " + DEFAULT_SLOTS.length + " หมวด ข้ามหมวด " + key);
                continue;
            }
            Material icon = Material.matchMaterial(c.getString("icon", "CHEST"));
            if (icon == null) icon = Material.CHEST;
            List<Entry> list = new ArrayList<>();
            ConfigurationSection is = c.getConfigurationSection("items");
            if (is != null) {
                for (String mk : is.getKeys(false)) {
                    Material m = Material.matchMaterial(mk);
                    ConfigurationSection e = is.getConfigurationSection(mk);
                    if (m == null || !m.isItem() || e == null) {
                        plugin.getLogger().warning("shop.yml: ข้ามไอเทม '" + mk + "' ในหมวด " + key);
                        continue;
                    }
                    long buy = Math.round(e.getDouble("buy", -1) * 100.0);
                    long sell = Math.round(e.getDouble("sell", -1) * 100.0);
                    if (buy <= 0 && sell <= 0) continue;
                    list.add(new Entry(m, buy, sell));
                }
            }
            categories.add(new Category(key, c.getString("name", key), icon, c.getInt("slot", -1), list));
        }
        // จัดช่องในเมนูหลัก: ช่องที่ระบุเองก่อน แล้วที่เหลือเรียงตามค่าเริ่มต้น
        Set<Integer> used = new HashSet<>();
        used.add(CLOSE_SLOT);
        for (Category c : categories) if (c.slot() >= 0 && c.slot() < 27) used.add(c.slot());
        int di = 0;
        for (int i = 0; i < categories.size(); i++) {
            Category c = categories.get(i);
            if (c.slot() >= 0 && c.slot() < 27 && c.slot() != CLOSE_SLOT) continue;
            while (di < DEFAULT_SLOTS.length && used.contains(DEFAULT_SLOTS[di])) di++;
            int slot = di < DEFAULT_SLOTS.length ? DEFAULT_SLOTS[di++] : 26;
            used.add(slot);
            categories.set(i, new Category(c.key(), c.name(), c.icon(), slot, c.items()));
        }
    }

    // ------------------------------------------------------------ command

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload") && sender.hasPermission("vortexcore.eco.admin")) {
            load();
            sender.sendMessage(Component.text("โหลด shop.yml ใหม่แล้ว (" + categories.size() + " หมวด)", NamedTextColor.GREEN));
            return true;
        }
        if (!(sender instanceof Player p)) {
            sender.sendMessage("ใช้ได้เฉพาะผู้เล่น");
            return true;
        }
        if (!Smp.is(p)) {
            Smp.notHere(p);
            return true;
        }
        if (categories.isEmpty()) {
            p.sendMessage(Component.text("ร้านค้ายังไม่มีสินค้า", NamedTextColor.RED));
            return true;
        }
        openMain(p);
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1 && sender.hasPermission("vortexcore.eco.admin")) return List.of("reload");
        return List.of();
    }

    // ------------------------------------------------------------ GUI

    private static ItemStack named(Material m, int amount, String name, NamedTextColor color, List<Component> lore) {
        ItemStack it = GuiUtil.icon(m, Component.text(name, color), lore);
        it.setAmount(Math.max(1, Math.min(64, amount)));
        return it;
    }

    private void openMain(Player p) {
        Holder h = new Holder(Type.MAIN, null, 0);
        Inventory inv = Bukkit.createInventory(h, 27, Component.text("Shop"));
        h.inv = inv;
        for (Category c : categories) {
            inv.setItem(c.slot(), GuiUtil.icon(c.icon(), Component.text(c.name(), NamedTextColor.YELLOW),
                    List.of(GuiUtil.line(c.items().size() + " items", NamedTextColor.GRAY))));
            h.cats.put(c.slot(), c);
        }
        inv.setItem(CLOSE_SLOT, named(Material.RED_WOOL, 1, "Close", NamedTextColor.RED, null));
        p.openInventory(inv);
    }

    private void openCat(Player p, Category cat, int page) {
        int n = cat.items().size();
        int perPage = n <= 9 ? 9 : Math.min(n, 45);
        int pages = Math.max(1, (n + perPage - 1) / perPage);
        page = Math.max(0, Math.min(page, pages - 1));
        int from = page * perPage;
        int count = Math.min(perPage, n - from);
        int start, size;
        if (n <= 9) {
            start = 9;
            size = 27;
        } else {
            start = 0;
            size = (((count + 8) / 9) + 1) * 9;
        }
        Holder h = new Holder(Type.CAT, cat, page);
        Component title = Component.text("Shop | " + cat.name() + (pages > 1 ? " (" + (page + 1) + "/" + pages + ")" : ""));
        Inventory inv = Bukkit.createInventory(h, size, title);
        h.inv = inv;
        for (int i = 0; i < count; i++) {
            Entry e = cat.items().get(from + i);
            List<Component> lore = new ArrayList<>();
            if (e.buy() > 0) lore.add(GuiUtil.line("Buy: " + eco.format(e.buy()) + " (Left click)", NamedTextColor.GREEN));
            if (e.sell() > 0) lore.add(GuiUtil.line("Sell: " + eco.format(e.sell()) + " (Right click)", NamedTextColor.GOLD));
            ItemStack it = new ItemStack(e.mat());
            var meta = it.getItemMeta();
            meta.lore(lore);
            it.setItemMeta(meta);
            inv.setItem(start + i, it);
            h.entries.put(start + i, e);
        }
        h.back = size - 5;
        inv.setItem(h.back, named(Material.ARROW, 1, "Back", NamedTextColor.RED, null));
        if (pages > 1) {
            if (page > 0) {
                h.prev = h.back - 1;
                inv.setItem(h.prev, named(Material.SPECTRAL_ARROW, 1, "Previous", NamedTextColor.YELLOW, null));
            }
            if (page < pages - 1) {
                h.next = h.back + 1;
                inv.setItem(h.next, named(Material.SPECTRAL_ARROW, 1, "Next", NamedTextColor.YELLOW, null));
            }
        }
        p.openInventory(inv);
    }

    private void openQty(Player p, Category cat, int page, Entry entry, boolean buying) {
        Holder h = new Holder(Type.QTY, cat, page);
        h.entry = entry;
        h.buying = buying;
        h.amount = 1;
        Component title = Component.text(buying ? "Buying " : "Selling ")
                .append(Component.translatable(entry.mat().translationKey()));
        Inventory inv = Bukkit.createInventory(h, 27, title);
        h.inv = inv;
        renderQty(h, p);
        p.openInventory(inv);
    }

    private void renderQty(Holder h, Player p) {
        Inventory inv = h.inv;
        inv.clear();
        int max = Math.max(1, h.entry.mat().getMaxStackSize());
        int a = h.amount;
        long unit = h.buying ? h.entry.buy() : h.entry.sell();

        ItemStack main = new ItemStack(h.entry.mat(), a);
        var meta = main.getItemMeta();
        meta.lore(List.of(
                GuiUtil.line((h.buying ? "Price: " : "Sell price: ") + eco.format(unit) + " each", NamedTextColor.GRAY),
                GuiUtil.line("Total: " + eco.format(unit * a), NamedTextColor.GOLD),
                GuiUtil.line("Balance: " + eco.format(eco.cents(p.getUniqueId())), NamedTextColor.GREEN)));
        main.setItemMeta(meta);
        inv.setItem(13, main);

        if (a > 1) inv.setItem(9, named(Material.RED_STAINED_GLASS_PANE, 1, "Set to 1", NamedTextColor.RED, null));
        if (a - 10 >= 1) inv.setItem(10, named(Material.RED_STAINED_GLASS_PANE, 10, "-10", NamedTextColor.RED, null));
        if (a > 1) inv.setItem(11, named(Material.RED_STAINED_GLASS_PANE, 1, "-1", NamedTextColor.RED, null));
        if (a < max) inv.setItem(15, named(Material.LIME_STAINED_GLASS_PANE, 1, "+1", NamedTextColor.GREEN, null));
        if (a + 10 <= max) inv.setItem(16, named(Material.LIME_STAINED_GLASS_PANE, 10, "+10", NamedTextColor.GREEN, null));
        if (a < max) inv.setItem(17, named(Material.LIME_STAINED_GLASS_PANE, max, "Set to " + max, NamedTextColor.GREEN, null));

        inv.setItem(21, named(Material.RED_WOOL, 1, "Cancel", NamedTextColor.RED, null));
        inv.setItem(23, named(Material.LIME_WOOL, 1, "Confirm", NamedTextColor.GREEN,
                List.of(GuiUtil.line((h.buying ? "Buy " : "Sell ") + a + " for " + eco.format(unit * a), NamedTextColor.GRAY))));
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();

        switch (h.type) {
            case MAIN -> {
                if (slot == CLOSE_SLOT) {
                    p.closeInventory();
                    return;
                }
                Category c = h.cats.get(slot);
                if (c != null) openCat(p, c, 0);
            }
            case CAT -> {
                if (slot == h.back) openMain(p);
                else if (slot == h.prev) openCat(p, h.cat, h.page - 1);
                else if (slot == h.next) openCat(p, h.cat, h.page + 1);
                else {
                    Entry en = h.entries.get(slot);
                    if (en == null) return;
                    switch (e.getClick()) {
                        case LEFT, SHIFT_LEFT -> {
                            if (en.buy() > 0) openQty(p, h.cat, h.page, en, true);
                            else bar(p, "This item can't be bought", NamedTextColor.RED);
                        }
                        case RIGHT, SHIFT_RIGHT -> {
                            if (en.sell() > 0) openQty(p, h.cat, h.page, en, false);
                            else bar(p, "This item can't be sold", NamedTextColor.RED);
                        }
                        default -> { }
                    }
                }
            }
            case QTY -> {
                int max = Math.max(1, h.entry.mat().getMaxStackSize());
                int old = h.amount;
                switch (slot) {
                    case 9 -> { if (old > 1) h.amount = 1; }
                    case 10 -> { if (old - 10 >= 1) h.amount = old - 10; }
                    case 11 -> { if (old > 1) h.amount = old - 1; }
                    case 15 -> { if (old < max) h.amount = old + 1; }
                    case 16 -> { if (old + 10 <= max) h.amount = old + 10; }
                    case 17 -> { if (old < max) h.amount = max; }
                    case 21 -> {
                        openCat(p, h.cat, h.page);
                        return;
                    }
                    case 23 -> {
                        if (h.buying) buy(p, h.entry, h.amount);
                        else sell(p, h.entry, h.amount);
                        renderQty(h, p);
                        return;
                    }
                    default -> { return; }
                }
                if (h.amount != old) {
                    bar(p, "Set to " + h.amount, NamedTextColor.GREEN);
                    renderQty(h, p);
                }
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    // ------------------------------------------------------------ trade

    private void buy(Player p, Entry en, int amount) {
        if (en.buy() <= 0) {
            bar(p, "This item can't be bought", NamedTextColor.RED);
            return;
        }
        long total = en.buy() * amount;
        EconomyManager.Tx tx = eco.withdraw(p.getUniqueId(), total);
        if (tx != EconomyManager.Tx.SUCCESS) {
            bar(p, tx == EconomyManager.Tx.INSUFFICIENT ? "Not enough money (need " + eco.format(total) + ")" : "Purchase failed", NamedTextColor.RED);
            return;
        }
        Map<Integer, ItemStack> rest = p.getInventory().addItem(new ItemStack(en.mat(), amount));
        int notGiven = 0;
        for (ItemStack r : rest.values()) notGiven += r.getAmount();
        if (notGiven > 0) {
            eco.deposit(p.getUniqueId(), en.buy() * notGiven);
            if (notGiven == amount) {
                bar(p, "Inventory full", NamedTextColor.RED);
                return;
            }
            bar(p, "Inventory full — bought " + (amount - notGiven), NamedTextColor.YELLOW);
            return;
        }
        bar(p, "Bought " + amount + " for " + eco.format(total), NamedTextColor.GREEN);
    }

    private void sell(Player p, Entry en, int amount) {
        if (en.sell() <= 0) {
            bar(p, "This item can't be sold", NamedTextColor.RED);
            return;
        }
        PlayerInventory inv = p.getInventory();
        ItemStack[] contents = inv.getStorageContents();
        int have = 0;
        for (ItemStack it : contents) {
            if (it != null && it.getType() == en.mat() && !it.hasItemMeta()) have += it.getAmount();
        }
        if (have < amount) {
            bar(p, "You only have " + have, NamedTextColor.RED);
            return;
        }
        long total = en.sell() * amount;
        if (eco.deposit(p.getUniqueId(), total) != EconomyManager.Tx.SUCCESS) {
            bar(p, "Sale failed (balance cap reached)", NamedTextColor.RED);
            return;
        }
        int remove = amount;
        for (int i = 0; i < contents.length && remove > 0; i++) {
            ItemStack it = contents[i];
            if (it == null || it.getType() != en.mat() || it.hasItemMeta()) continue;
            int take = Math.min(remove, it.getAmount());
            remove -= take;
            if (take == it.getAmount()) {
                inv.setItem(i, null);
            } else {
                ItemStack rest = it.clone();
                rest.setAmount(it.getAmount() - take);
                inv.setItem(i, rest);
            }
        }
        bar(p, "Sold " + amount + " for " + eco.format(total), NamedTextColor.GOLD);
    }

    private static void bar(Player p, String text, NamedTextColor color) {
        p.sendActionBar(Component.text(text, color));
    }
}
