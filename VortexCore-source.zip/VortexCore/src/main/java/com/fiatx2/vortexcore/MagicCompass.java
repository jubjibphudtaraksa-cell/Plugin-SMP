package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.CompassMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.List;

/** สร้างและตรวจสอบไอเท็ม "เข็มทิศวิเศษ" (ติดแท็กด้วย PersistentDataContainer) */
public final class MagicCompass {

    private final NamespacedKey tag;

    public MagicCompass(Plugin plugin) {
        this.tag = new NamespacedKey(plugin, "magic_compass");
    }

    public ItemStack create() {
        ItemStack item = new ItemStack(Material.COMPASS);
        CompassMeta meta = (CompassMeta) item.getItemMeta();

        meta.displayName(Component.text("เข็มทิศวิเศษ", NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("ชี้ไปหาผู้เล่นที่ใกล้ที่สุด", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("จะพังทันทีเมื่อเข้าใกล้เป้าหมายเกินกำหนด", NamedTextColor.DARK_RED)
                        .decoration(TextDecoration.ITALIC, false)));
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(tag, PersistentDataType.BYTE, (byte) 1);

        item.setItemMeta(meta);
        return item;
    }

    public boolean isMagic(ItemStack item) {
        if (item == null || item.getType() != Material.COMPASS || !item.hasItemMeta()) {
            return false;
        }
        return item.getItemMeta().getPersistentDataContainer().has(tag, PersistentDataType.BYTE);
    }
}
