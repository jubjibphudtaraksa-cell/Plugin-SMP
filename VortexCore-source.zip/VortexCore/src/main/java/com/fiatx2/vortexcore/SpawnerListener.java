package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;

public class SpawnerListener implements Listener {

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Block block = e.getBlock();
        if (!Smp.is(block.getWorld())) return;
        if (block.getType() != Material.SPAWNER) return;
        if (e.getPlayer().getGameMode() == GameMode.CREATIVE) return;

        ItemStack tool = e.getPlayer().getInventory().getItemInMainHand();
        if (tool.getEnchantmentLevel(Enchantment.SILK_TOUCH) <= 0) return;

        if (!(block.getState() instanceof CreatureSpawner cs)) return;
        EntityType type = cs.getSpawnedType();
        if (type == null) return;

        ItemStack item = new ItemStack(Material.SPAWNER);
        BlockStateMeta meta = (BlockStateMeta) item.getItemMeta();
        CreatureSpawner stored = (CreatureSpawner) meta.getBlockState();
        stored.setSpawnedType(type);
        meta.setBlockState(stored);
        meta.displayName(Component.translatable(type.translationKey())
                .append(Component.text(" Spawner"))
                .decoration(TextDecoration.ITALIC, false));
        item.setItemMeta(meta);

        e.setExpToDrop(0);
        e.setDropItems(false);
        block.getWorld().dropItemNaturally(block.getLocation().add(0.5, 0.5, 0.5), item);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (!Smp.is(e.getBlockPlaced().getWorld())) return;
        ItemStack inHand = e.getItemInHand();
        if (inHand.getType() != Material.SPAWNER) return;
        if (!(inHand.getItemMeta() instanceof BlockStateMeta meta)) return;
        if (!(meta.getBlockState() instanceof CreatureSpawner src)) return;

        EntityType type = src.getSpawnedType();
        if (type == null) return;

        if (e.getBlockPlaced().getState() instanceof CreatureSpawner placed) {
            placed.setSpawnedType(type);
            placed.update(true, false);
        }
    }
}
