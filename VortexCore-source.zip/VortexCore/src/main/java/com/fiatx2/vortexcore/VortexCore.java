package com.fiatx2.vortexcore;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public final class VortexCore extends JavaPlugin {

    private KeyManager keyManager;
    private MagicCompass magicCompass;
    private RtpModule rtp;
    private ScoreboardModule scoreboard;
    private CompassTask compassTask;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Smp.init(this);
        if (Smp.world() == null) {
            getLogger().warning("ไม่พบโลกชื่อ '" + Smp.name() + "' ตอนนี้ — ฟีเจอร์ทั้งหมดจะไม่ทำงานจนกว่าโลกนี้จะถูกโหลด");
        }

        // AutoClear
        AutoClearModule autoClear = new AutoClearModule(this);
        getServer().getPluginManager().registerEvents(new SpawnerListener(), this);
        bind("clearworld", autoClear);
        autoClear.start();

        // RTP
        rtp = new RtpModule(this);
        getServer().getPluginManager().registerEvents(rtp, this);
        bind("rtp", rtp);

        // TPA / spawn / settings / home
        TpaModule tpa = new TpaModule(this);
        tpa.init();
        for (String c : List.of("tpa", "tpahere", "tpaccept", "tpdeny", "spawn", "settings", "sethome", "home")) {
            bind(c, tpa);
        }

        // Lobby
        bind("lobby", new LobbyModule(this, tpa));

        // Scoreboard
        scoreboard = new ScoreboardModule(this);
        getServer().getPluginManager().registerEvents(scoreboard, this);
        scoreboard.start();

        // KeyCompass
        keyManager = new KeyManager(this);
        keyManager.load();
        magicCompass = new MagicCompass(this);
        KeyCommands keyCommands = new KeyCommands(this);
        for (String c : List.of("key", "addkey", "dekey", "deakey", "showkey")) {
            bind(c, keyCommands);
        }
        long interval = Math.max(1L, getConfig().getLong("update-interval-ticks", 10L));
        compassTask = new CompassTask(this);
        compassTask.runTaskTimer(this, interval, interval);

        getLogger().info("VortexCore enabled (world: " + Smp.name() + ")");
    }

    @Override
    public void onDisable() {
        if (rtp != null) rtp.shutdown();
        if (scoreboard != null) scoreboard.shutdown();
        if (compassTask != null) compassTask.cancel();
        if (keyManager != null) keyManager.save();
    }

    private void bind(String name, Object handler) {
        PluginCommand cmd = getCommand(name);
        if (cmd == null) {
            getLogger().severe("Command '" + name + "' missing from plugin.yml");
            return;
        }
        cmd.setExecutor((org.bukkit.command.CommandExecutor) handler);
        if (handler instanceof org.bukkit.command.TabCompleter tc) cmd.setTabCompleter(tc);
    }

    public KeyManager keys() { return keyManager; }

    public MagicCompass magic() { return magicCompass; }
}
