# VortexCore (Paper 1.21.x)

รวม 5 ปลั๊กอิน: AutoClear, RTPMenu, SimpleTPA (tpa/spawn/home/settings/spawn-protect), VortexScoreboard, KeyCompass
**ทุกฟีเจอร์ทำงานเฉพาะในโลกชื่อ `smp`** (เปลี่ยนได้ที่ `world-name` ใน config.yml)

Build: `mvn clean package` -> `target/VortexCore-1.0.0.jar`

ย้ายข้อมูลเก่า: คัดลอก `homes.yml`, `settings.yml` (จาก plugins/SimpleTPA) และ `keys.yml` (จาก plugins/KeyCompass)
ไปไว้ใน `plugins/VortexCore/` แล้วลบปลั๊กอินเก่าทั้ง 5 ตัวออกจาก plugins/
