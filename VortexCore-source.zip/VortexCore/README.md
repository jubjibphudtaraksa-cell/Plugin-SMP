# VortexCore (Paper 1.21.x)

รวม 6 ระบบ: AutoClear, RTPMenu, SimpleTPA (tpa/spawn/home/settings/spawn-protect), VortexScoreboard, KeyCompass, Economy
**ทุกฟีเจอร์ทำงานเฉพาะในโลกชื่อ `smp`** (เปลี่ยนได้ที่ `world-name` ใน config.yml)

Build: `mvn clean package` -> `target/VortexCore-1.0.0.jar`

ย้ายข้อมูลเก่า: คัดลอก `homes.yml`, `settings.yml` (จาก plugins/SimpleTPA) และ `keys.yml` (จาก plugins/KeyCompass)
ไปไว้ใน `plugins/VortexCore/` แล้วลบปลั๊กอินเก่าทั้ง 5 ตัวออกจาก plugins/

## Economy
- `/balance [ผู้เล่น]` (`/bal`, `/money`), `/pay <ผู้เล่น> <จำนวน>`, `/baltop [หน้า]`
- แอดมิน: `/eco give|take|set|reset <ผู้เล่น> [จำนวน]` (permission `vortexcore.eco.admin`)
- จำนวนเงินพิมพ์ย่อได้: `1k`, `2.5m`, `1b`
- ข้อมูลเก็บที่ `plugins/VortexCore/economy.yml`, ลงทะเบียนเป็น Vault provider อัตโนมัติ (ถ้ามี Vault)
- ปรับค่าได้ที่ส่วน `economy:` ใน config.yml (เงินเริ่มต้น, ภาษีโอน, รางวัลฆ่ามอน ฯลฯ)
- ถ้ามี EssentialsX ให้ปิดระบบเงินฝั่ง Essentials (หรือลบคำสั่ง balance/pay/baltop/eco ของมัน) เพื่อไม่ให้ชนกัน
