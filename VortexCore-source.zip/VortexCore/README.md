# VortexCore (Paper 1.21.x)

รวม 8 ระบบ (+Shop, Auction): AutoClear, RTPMenu, SimpleTPA (tpa/spawn/home/settings/spawn-protect), VortexScoreboard, KeyCompass, Economy
**ทุกฟีเจอร์ทำงานเฉพาะในโลกชื่อ `smp`** (เปลี่ยนได้ที่ `world-name` ใน config.yml)

Build: `mvn clean package` -> `target/VortexCore-1.0.0.jar`

ย้ายข้อมูลเก่า: คัดลอก `homes.yml`, `settings.yml` (จาก plugins/SimpleTPA) และ `keys.yml` (จาก plugins/KeyCompass)
ไปไว้ใน `plugins/VortexCore/` แล้วลบปลั๊กอินเก่าทั้ง 5 ตัวออกจาก plugins/

## Economy
- `/balance [ผู้เล่น]` (`/bal`, `/money`), `/pay <ผู้เล่น> <จำนวน>`, `/baltop [หน้า]`
- แอดมิน: `/eco give|take|set|reset <ผู้เล่น> [จำนวน]` (permission `vortexcore.eco.admin`)
- จำนวนเงินพิมพ์ย่อได้: `1k`, `2.5m`, `1b`
- ข้อมูลเก็บที่ `plugins/VortexCore/economy.yml`, ลงทะเบียนเป็น Vault provider อัตโนมัติ (ถ้ามี Vault)
- ปรับค่าได้ที่ส่วน `economy:` ใน config.yml (เงินเริ่มต้น, ภาษีโอน, รางวัลฆ่ามอน ฯลฯ)
- ไม่ต้องใช้ Essentials / Vault ก็ใช้ระบบเงินได้ (Vault ใช้เฉพาะให้ปลั๊กอินอื่นอ่านเงินชุดนี้)

## Shop / Auction (ต้องเปิด economy)
- `/shop` — ดูหัวข้อ Sell / Order ด้านล่าง (ถ้าเคยติดตั้งเวอร์ชันก่อนหน้า ให้ลบ `plugins/VortexCore/shop.yml` เก่าก่อน; ราคาแก้ในไฟล์นี้แล้ว `/shop reload`)
- `/ah` — ตลาดผู้เล่น: คลิกสินค้าเพื่อซื้อ
  - `/ah sell <ราคา> [จำนวน]` ลงขายไอเทมในมือ (ราคารวม, พิมพ์ย่อ 2k/1m ได้)
  - `/ah my` รายการของฉัน (คลิกเพื่อยกเลิก), `/ah claim` รับของที่หมดอายุ/ที่ค้างไว้
  - ตั้งค่าที่ส่วน `auction:` ใน config.yml (จำนวนที่ลงขายได้, อายุรายการ, ภาษี)

## Sell / Order (ต้องเปิด economy)
- `/shop` — ร้านค้าแบบ ShopPlugin (ใช้เงินของ VortexCore): คลิกซ้ายซื้อ (เลือกจำนวนได้), คลิกขวาขาย (Shift = ทั้งหมด), ไม่มีหมวดแร่ (ขายแร่ที่ `/sell`), หมวดเครื่องมือ 3x3 เนเธอร์ไรต์ซื้อได้อย่างเดียว; `/shop reload`, `/shop givehammer <ผู้เล่น> <pickaxe|shovel|axe|hoe>` (ต้องมีสิทธิ์ `vortexcore.eco.admin`)
- `/sell` — เมนูขายของ: วางไอเทมลงช่องด้านบนแล้วกดปุ่มสีเขียว ขายได้เกือบทุกอย่าง: ใช้ราคาจากหมวดและ `sell-prices` ใน `shop.yml` ส่วนไอเทมที่ไม่ได้ระบุขายที่ `sell.default-price` (config.yml) ยกเว้นของแอดมิน/ของหายาก (ลบ `shop.yml` เก่าก่อนอัปเดต) ไอเทมที่ไม่รับซื้อหรือมีชื่อ/เอนชานท์จะถูกคืนตอนปิดเมนู
- `/order` — ออเดอร์รับซื้อระหว่างผู้เล่น: คลิกออเดอร์เพื่อส่งของและรับเงินทันที
  - `/order create <ไอเทม|hand> <จำนวน> <ราคาต่อชิ้น>` สร้างออเดอร์ (ระบบกันเงินล่วงหน้า, พิมพ์ย่อ 2k/1m ได้)
  - `/order my` ออเดอร์ของฉัน (คลิกเพื่อยกเลิกและรับเงินคืน), `/order claim` รับของที่คนส่งให้
  - ตั้งค่าที่ส่วน `order:` ใน config.yml, ข้อมูลที่ `plugins/VortexCore/orders.yml`
